# PeerCraft

Build • Collaborate • Grow

## Setup (Supabase)
1. Supabase Dashboard → **SQL Editor** → paste `supabase/schema.sql` → **Run** (creates tables, security rules, the `avatars` storage bucket).
2. Dashboard → **Project Settings → API**: copy the **Project URL** and **anon public key**.
3. Copy `.env.example` to `.env` and fill both values. Restart `npm run dev`.
4. Optional: Authentication → Providers → Email → turn **Confirm email** off while developing, otherwise new users must click the emailed link before signing in.
5. Optional admin: set `VITE_ADMIN_EMAILS=you@college.edu` in `.env`, or `update profiles set role='admin' where email='you@college.edu';` in the SQL editor.

```
npm install
npm run dev     # http://localhost:5173
```
