/**
 * App-wide configuration.
 *
 * SHOW_SAMPLE_COMMUNITY: PeerCraft has no backend yet, so "other people" (their
 * profiles and active projects) come from `data/community.ts`, plus any other
 * accounts registered in this same browser. Set this to `false` once real
 * users/projects come from an API and the sample community should disappear.
 */
export const SHOW_SAMPLE_COMMUNITY = true;

/** Comma-separated emails that get the admin role at sign-up (Vite env: VITE_ADMIN_EMAILS). */
export const ADMIN_EMAILS: string[] = (import.meta.env.VITE_ADMIN_EMAILS || '')
  .split(',')
  .map((e: string) => e.trim().toLowerCase())
  .filter(Boolean);

/** Bump to wipe old demo data stored by earlier versions of the app. */
export const STORAGE_SCHEMA = '3';
