import { MatchQuery, PeerMatch, Project, UserProfile } from '../types';

const STOPWORDS = new Set([
  'a','an','and','or','the','for','with','who','whom','that','this','is','are','be','to','of','in','on','at','by','from',
  'me','my','i','we','our','need','needs','needed','want','wants','looking','look','find','finding','search','someone',
  'somebody','person','people','student','students','teammate','teammates','team','member','members','partner','partners',
  'mentor','help','experienced','experience','good','great','best','skilled','skill','skills','knows','know','knowing',
  'who','can','able','have','has','having','build','building','project','projects','developer','developers','engineer',
  'profile','profiles','match','matching','please','suitable','right','some','any','year','branch','using','use','work',
  'working','like','also','more','than','into','about','around','within','your','their','them','it','as',
]);

/** Keyword -> related skills/interests. Related hits count for less than direct hits. */
const RELATED: Record<string, string[]> = {
  frontend: ['react', 'tailwind css', 'ui/ux design', 'figma', 'next.js', 'typescript', 'javascript'],
  'front-end': ['react', 'tailwind css', 'ui/ux design', 'figma', 'next.js'],
  backend: ['node.js', 'go', 'postgresql', 'fastapi', 'docker', 'sql', 'rest apis'],
  'back-end': ['node.js', 'go', 'postgresql', 'fastapi', 'docker'],
  fullstack: ['react', 'node.js', 'postgresql', 'typescript'],
  'full-stack': ['react', 'node.js', 'postgresql', 'typescript'],
  design: ['ui/ux design', 'figma', 'cad', 'solidworks'],
  ui: ['ui/ux design', 'figma', 'tailwind css'],
  ux: ['ui/ux design', 'figma'],
  mobile: ['flutter', 'dart', 'react native', 'firebase'],
  app: ['flutter', 'react native', 'react'],
  ml: ['machine learning', 'pytorch', 'scikit-learn', 'python'],
  ai: ['machine learning', 'pytorch', 'nlp', 'python'],
  'machine learning': ['pytorch', 'scikit-learn', 'python', 'nlp'],
  data: ['python', 'sql', 'pandas', 'data visualization', 'r'],
  iot: ['arduino', 'raspberry pi', 'embedded c', 'mqtt'],
  hardware: ['arduino', 'raspberry pi', 'embedded c', 'pcb design', 'cad'],
  embedded: ['embedded c', 'arduino', 'raspberry pi'],
  robotics: ['arduino', 'embedded c', 'cad', 'control systems'],
  devops: ['docker', 'kubernetes', 'go'],
  cloud: ['docker', 'kubernetes', 'cloud architecture'],
  web3: ['solidity', 'smart contracts', 'ethers.js'],
  blockchain: ['solidity', 'smart contracts'],
  js: ['javascript', 'typescript', 'react', 'node.js'],
  ts: ['typescript'],
  py: ['python'],
  reactjs: ['react'],
  nodejs: ['node.js'],
  nextjs: ['next.js'],
  cpp: ['c++'],
};

const ALIASES: Record<string, string> = {
  reactjs: 'react', nodejs: 'node.js', nextjs: 'next.js', js: 'javascript', ts: 'typescript', py: 'python',
  cpp: 'c++', ml: 'machine learning', 'ui/ux': 'ui/ux design', uiux: 'ui/ux design', figma: 'figma',
};

const LEVEL_WEIGHT = { Beginner: 0.5, Intermediate: 0.7, Advanced: 0.9, Expert: 1 } as const;
const LEVEL_RANK = { Any: 0, Beginner: 1, Intermediate: 2, Advanced: 3, Expert: 4 } as const;

const norm = (s: string) => s.toLowerCase().trim();

/** Turn free text into primary keywords. Known multi-word skills are kept intact. */
export const extractKeywords = (text: string, vocabulary: string[] = []): string[] => {
  let rest = ' ' + norm(text).replace(/[,;|\n]+/g, ' , ') + ' ';
  const found: string[] = [];

  const phrases = Array.from(new Set(vocabulary.map(norm).filter((v) => v.includes(' ') || v.includes('/'))))
    .sort((a, b) => b.length - a.length);
  for (const ph of phrases) {
    const needle = ' ' + ph + ' ';
    if (rest.includes(needle)) {
      found.push(ph);
      rest = rest.split(needle).join(' , ');
    }
  }

  for (const raw of rest.split(/[\s,]+/)) {
    const tok = raw.replace(/^[^a-z0-9+#./]+|[^a-z0-9+#./]+$/g, '');
    if (!tok || tok.length < 2 || STOPWORDS.has(tok) || /^\d+$/.test(tok)) continue;
    found.push(ALIASES[tok] ?? tok);
  }
  return Array.from(new Set(found));
};

export const collectVocabulary = (users: UserProfile[], projects: Project[]): string[] => {
  const v = new Set<string>();
  users.forEach((u) => {
    u.skills.forEach((s) => v.add(s.name));
    u.interests.forEach((i) => v.add(i));
  });
  projects.forEach((p) => {
    p.technologies.forEach((t) => v.add(t));
    p.requiredSkills.forEach((t) => v.add(t));
  });
  return Array.from(v);
};

const textHit = (haystack: string, needle: string) => {
  const h = norm(haystack);
  const n = norm(needle);
  if (!n) return false;
  if (h === n) return true;
  // whole-word-ish containment, but allow short tokens only as exact matches
  if (n.length <= 2) return h.split(/[^a-z0-9+#.]+/).includes(n);
  return h.includes(n) || (h.length > 3 && n.includes(h));
};

interface Scored {
  points: number;
  reasons: string[];
  skills: string[];
}

const scoreKeyword = (
  user: UserProfile,
  userProjects: Project[],
  kw: string,
  weight: number,
  verifiedOnly: boolean
): Scored => {
  let points = 0;
  const reasons: string[] = [];
  const skills: string[] = [];

  for (const s of user.skills) {
    if (verifiedOnly && !s.verified) continue;
    if (textHit(s.name, kw)) {
      const p = 3 * LEVEL_WEIGHT[s.proficiency] * (s.verified ? 1 : 0.9);
      if (p > points) points = p;
      skills.push(s.name);
      reasons.push(`${s.name} (${s.proficiency}${s.verified ? ', verified' : ''})`);
    }
  }
  if (points === 0) {
    const interest = user.interests.find((i) => textHit(i, kw));
    if (interest) {
      points = 2;
      reasons.push(`Interested in ${interest}`);
    }
  }
  if (points === 0) {
    const proj = userProjects.find(
      (p) => p.technologies.some((t) => textHit(t, kw)) || p.requiredSkills.some((t) => textHit(t, kw))
    );
    if (proj) {
      points = 1.5;
      reasons.push(`Works on ${proj.title}`);
    }
  }
  if (points === 0 && (textHit(user.bio, kw) || textHit(user.branch, kw))) {
    points = 1;
    reasons.push(`Mentions "${kw}" in profile`);
  }
  return { points: points * weight, reasons, skills };
};

export const matchPeers = (
  query: MatchQuery,
  candidates: UserProfile[],
  projects: Project[],
  vocabulary?: string[]
): PeerMatch[] => {
  const vocab = vocabulary ?? collectVocabulary(candidates, projects);
  const primary = extractKeywords(query.text, vocab);

  const related = new Set<string>();
  primary.forEach((k) => (RELATED[k] ?? []).forEach((r) => !primary.includes(r) && related.add(r)));

  const results: PeerMatch[] = [];
  for (const user of candidates) {
    if (query.branch !== 'Any' && user.branch !== query.branch) continue;
    if (query.year !== 'Any' && user.academicYear !== query.year) continue;

    const userProjects = projects.filter((p) => p.members.some((m) => m.userId === user.id));
    const reasons: string[] = [];
    const matchedSkills = new Set<string>();
    let total = 0;

    if (primary.length > 0) {
      for (const kw of primary) {
        const r = scoreKeyword(user, userProjects, kw, 1, query.verifiedOnly);
        total += r.points;
        r.reasons.slice(0, 1).forEach((x) => reasons.push(x));
        r.skills.forEach((x) => matchedSkills.add(x));
      }
      for (const kw of related) {
        const r = scoreKeyword(user, userProjects, kw, 0.45, query.verifiedOnly);
        if (r.points > 0) {
          total += r.points / Math.max(1, related.size / 3);
          r.skills.forEach((x) => matchedSkills.add(x));
          if (reasons.length < 3) reasons.push(`Related: ${r.reasons[0]}`);
        }
      }
      if (query.minProficiency !== 'Any') {
        const need = LEVEL_RANK[query.minProficiency];
        const ok = user.skills.some(
          (s) =>
            LEVEL_RANK[s.proficiency] >= need &&
            primary.concat(Array.from(related)).some((k) => textHit(s.name, k))
        );
        if (!ok) continue;
      }
      if (total <= 0) continue;
    } else {
      // No keywords: rank by reputation and track record.
      total = user.reputation * 0.6 + Math.min(user.completedProjectsCount, 8) * 0.15;
      reasons.push(`Reputation ${user.reputation.toFixed(1)} • ${user.completedProjectsCount} completed projects`);
    }

    const max = primary.length > 0 ? 3 * primary.length : 4.2;
    const coverage = Math.min(1, total / max);
    const repBonus = (user.reputation / 5) * 8;
    const score = Math.max(1, Math.min(99, Math.round(coverage * 88 + repBonus)));

    results.push({
      userId: user.id,
      score,
      reasons: Array.from(new Set(reasons)).slice(0, 4),
      matchedSkills: Array.from(matchedSkills),
    });
  }

  return results.sort((a, b) => b.score - a.score);
};

/** Suggest teammates for the dashboard from the user's own gaps and project needs. */
export const recommendTeammates = (
  me: UserProfile,
  users: UserProfile[],
  projects: Project[],
  limit = 3
): { user: UserProfile; match: PeerMatch; reason: string }[] => {
  const mySkills = new Set(me.skills.map((s) => norm(s.name)));
  const myProjects = projects.filter((p) => p.members.some((m) => m.userId === me.id));
  const needed = new Set<string>();
  myProjects.forEach((p) => p.requiredSkills.forEach((s) => !mySkills.has(norm(s)) && needed.add(s)));
  me.interests.forEach((i) => needed.add(i));

  const text = Array.from(needed).join(', ');
  const candidates = users.filter((u) => u.id !== me.id);
  const matches = matchPeers(
    { text, branch: 'Any', year: 'Any', minProficiency: 'Any', verifiedOnly: false },
    candidates,
    projects
  );
  const list = (matches.length ? matches : matchPeers(
    { text: '', branch: 'Any', year: 'Any', minProficiency: 'Any', verifiedOnly: false }, candidates, projects)
  ).slice(0, limit);

  return list.map((m) => ({
    user: candidates.find((u) => u.id === m.userId)!,
    match: m,
    reason: m.reasons[0] ?? 'Active on campus',
  }));
};
