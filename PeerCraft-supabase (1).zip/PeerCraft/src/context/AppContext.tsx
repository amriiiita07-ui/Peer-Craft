import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  UserProfile,
  PlatformConnection,
  CreditTransaction,
  ActivityHistoryItem,
  CodingQuestion,
  Project,
  ResourceItem,
  MicroGig,
  CampusEvent,
  CommunityPost,
  NotificationItem,
  RewardRule,
  AuditLogItem,
  AIMessage,
  AIMentorMode,
  MatchQuery,
  QuickActionItem,
} from '../types';
import {
  defaultQuickActions,
  initialCodingQuestions,
  initialResources,
  initialMicroGigs,
  initialEvents,
  initialRewardRules,
} from '../data/mockData';
import { SHOW_SAMPLE_COMMUNITY, STORAGE_SCHEMA } from '../config';
import { supabase } from '../lib/supabase';
import { matchPeers, collectVocabulary } from '../utils/matching';

export type ThemeMode = 'light' | 'dark';

export interface RegisterInput {
  fullName: string;
  email: string;
  password: string;
  college: string;
  branch: string;
  academicYear: string;
  githubUrl?: string;
  linkedinUrl?: string;
  leetcodeUrl?: string;
  hackerrankUrl?: string;
}

interface AppContextType {
  // Auth & profile
  currentUser: UserProfile;
  isAuthenticated: boolean;
  authReady: boolean;
  register: (input: RegisterInput) => Promise<{ ok: boolean; error?: string; needsEmailConfirmation?: boolean }>;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  allUsers: UserProfile[];
  getUserById: (id: string) => UserProfile | undefined;
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<{ ok: boolean; error?: string }>;
  uploadAvatar: (file: File) => Promise<{ ok: boolean; error?: string }>;
  refreshData: () => Promise<void>;

  // Theme
  theme: ThemeMode;
  toggleTheme: () => void;
  setTheme: (t: ThemeMode) => void;

  // Credit balance and transactions
  availableCredits: number;
  lifetimeEarned: number;
  lifetimeSpent: number;
  transactions: CreditTransaction[];
  history: ActivityHistoryItem[];
  addHistoryItem: (item: Omit<ActivityHistoryItem, 'id' | 'timestamp' | 'userId'>) => void;

  // Platform connections & earning
  platformConnections: PlatformConnection[];
  updatePlatformConnection: (platform: string, username: string, profileUrl: string) => void;
  claimPlatformReward: (platform: string, activityName: string, amount: number) => { success: boolean; message: string };

  // Coding arena & question unlock flow
  codingQuestions: CodingQuestion[];
  unlockedQuestionIds: string[];
  unlockQuestion: (questionId: string) => { success: boolean; reason?: string; question?: CodingQuestion };
  addCodingQuestion: (question: Omit<CodingQuestion, 'id' | 'createdAt'>) => void;
  updateCodingQuestion: (id: string, updates: Partial<CodingQuestion>) => void;
  verifyQuestionLink: (id: string) => void;

  // Projects
  projects: Project[];
  /** Active projects owned by / joined by other people (for the discovery feed). */
  otherPeoplesActiveProjects: Project[];
  activeProjectsCount: number;
  createProject: (projectData: Omit<Project, 'id' | 'createdAt' | 'lastUpdated' | 'ownerId' | 'ownerName' | 'members' | 'memberCount' | 'isUserEnrolled'>) => void;
  joinProject: (projectId: string, role?: string) => void;

  // Resources
  resources: ResourceItem[];
  borrowedResourcesCount: number;
  borrowResource: (resourceId: string) => { success: boolean; message: string };
  returnResource: (resourceId: string) => { success: boolean; message: string };

  // Micro-gigs
  microGigs: MicroGig[];
  applyToGig: (gigId: string) => void;
  createGig: (gig: Omit<MicroGig, 'id' | 'creatorId' | 'creatorName' | 'applicantsCount' | 'createdAt' | 'status'>) => void;

  // Events
  events: CampusEvent[];
  registerForEvent: (eventId: string) => void;

  // Community
  communityPosts: CommunityPost[];
  createCommunityPost: (title: string, content: string, category: CommunityPost['category'], tags: string[]) => void;
  togglePostUpvote: (postId: string) => void;
  addCommentToPost: (postId: string, text: string) => void;

  // Notifications
  notifications: NotificationItem[];
  unreadNotificationsCount: number;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;

  // Admin & Rules
  signupBonusAmount: number;
  setSignupBonusAmount: (amount: number) => void;
  rewardRules: RewardRule[];
  updateRewardRule: (id: string, updates: Partial<RewardRule>) => void;
  auditLogs: AuditLogItem[];
  addAuditLog: (action: string, targetType: string, targetId: string, details: string) => void;

  // AI Mentor
  aiMessages: AIMessage[];
  aiMentorMode: AIMentorMode;
  setAiMentorMode: (mode: AIMentorMode) => void;
  isAiMentorOpen: boolean;
  setIsAiMentorOpen: (open: boolean) => void;
  selectedQuestionContext: CodingQuestion | null;
  setSelectedQuestionContext: (q: CodingQuestion | null) => void;
  sendAiMessage: (messageText: string) => void;
  findPeerMatches: (query: MatchQuery) => void;
  clearAiMessages: () => void;
  isAiThinking: boolean;

  // Global search
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Responsive Sidebar state
  isSidebarCollapsed: boolean;
  toggleSidebarCollapse: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;

  // Movable Quick Actions
  quickActions: QuickActionItem[];
  reorderQuickActions: (newActions: QuickActionItem[]) => void;
  moveQuickAction: (index: number, direction: 'up' | 'down') => void;
  resetQuickActions: () => void;

  // Avatar / profile picture
  showAvatarPicker: boolean;
  setShowAvatarPicker: (show: boolean) => void;
  updateAvatar: (avatarUrl: string, statusEmoji?: string) => void;

  // Fullscreen support
  isFullscreen: boolean;
  toggleFullscreen: () => void;

  // Wipe all locally stored data (accounts, projects, everything)
  resetAllLocalData: () => void;
  dataError: string | null;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// ---------------------------------------------------------------------------
// Storage helpers
// ---------------------------------------------------------------------------
const readJSON = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw !== null ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};
const writeJSON = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    // Storage can be full (e.g. a very large uploaded photo); keep the app running.
    console.warn('PeerCraft: could not persist', key, e);
  }
};

/** Wipe data written by older builds (which shipped a demo user and fake stats). */
const migrateStorage = () => {
  try {
    if (localStorage.getItem('peercraft_schema') === STORAGE_SCHEMA) return;
    Object.keys(localStorage)
      .filter((k) => k.startsWith('peercraft'))
      .forEach((k) => {
        if (k !== 'peercraft_theme' && k !== 'peercraft_sidebar_collapsed') localStorage.removeItem(k);
      });
    localStorage.setItem('peercraft_schema', STORAGE_SCHEMA);
  } catch {
    /* ignore */
  }
};
migrateStorage();

const scoped = (uid: string, name: string) => `peercraft:${uid}:${name}`;

const GUEST_USER: UserProfile = {
  id: '',
  fullName: 'Guest',
  firstName: 'Guest',
  email: '',
  avatarUrl: '',
  college: '',
  branch: '',
  academicYear: '',
  bio: '',
  role: 'student',
  reputation: 0,
  profileVisibility: 'private',
  interests: [],
  skills: [],
  completedProjectsCount: 0,
  signupBonusAwarded: false,
  createdAt: '',
};

export const usernameFromUrl = (url?: string): string => {
  if (!url) return '';
  try {
    const parts = new URL(url).pathname.split('/').filter(Boolean);
    const cleaned = parts.filter((p) => !['u', 'in', 'profile', 'profiles'].includes(p));
    return cleaned[cleaned.length - 1] || '';
  } catch {
    return '';
  }
};

const buildPlatforms = (u: UserProfile, prev?: PlatformConnection[]): PlatformConnection[] => {
  const defs: { platform: PlatformConnection['platform']; displayName: string; url?: string; cap: number; acts: string[] }[] = [
    { platform: 'leetcode', displayName: 'LeetCode', url: u.leetcodeUrl, cap: 100,
      acts: ['Daily Challenge streak (+25)', 'Solved Medium/Hard question (+25)', 'Contest participation (+50)'] },
    { platform: 'hackerrank', displayName: 'HackerRank', url: u.hackerrankUrl, cap: 100,
      acts: ['Skill Certification Badge (+50)', 'Qualifying Assessment pass (+25)', 'Algorithm track milestones (+25)'] },
    { platform: 'github', displayName: 'GitHub', url: u.githubUrl, cap: 150,
      acts: ['Merged pull request in active project (+50)', 'Verified code commits (+25)', 'Open source documentation contribution (+25)'] },
    { platform: 'linkedin', displayName: 'LinkedIn', url: u.linkedinUrl, cap: 50,
      acts: ['Verified internship / project post (+50)', 'Skill assessment badge credential (+25)'] },
  ];
  return defs.map((d) => {
    const existing = prev?.find((p) => p.platform === d.platform);
    const username = usernameFromUrl(d.url);
    return {
      id: `pc_${d.platform}`,
      platform: d.platform,
      displayName: d.displayName,
      username: d.url ? username : existing?.username ?? '',
      profileUrl: d.url ?? existing?.profileUrl ?? '',
      isConnected: Boolean(d.url) || Boolean(existing?.isConnected),
      isVerified: existing?.isVerified ?? false,
      creditsEarnedToday: existing?.creditsEarnedToday ?? 0,
      dailyCap: d.cap,
      lastSyncAt: existing?.lastSyncAt,
      eligibleActivities: d.acts,
    };
  });
};


// ---------------------------------------------------------------------------
// Supabase row <-> app type mappers
// ---------------------------------------------------------------------------
/* eslint-disable @typescript-eslint/no-explicit-any */
const profileFromRow = (r: any): UserProfile => ({
  id: r.id,
  fullName: r.full_name || r.email?.split('@')[0] || 'Student',
  firstName: (r.full_name || r.email?.split('@')[0] || 'Student').split(' ')[0],
  email: r.email ?? '',
  avatarUrl: r.avatar_url ?? '',
  statusEmoji: r.status_emoji ?? undefined,
  college: r.college ?? '',
  branch: r.branch ?? '',
  academicYear: r.academic_year ?? '',
  bio: r.bio ?? '',
  role: r.role ?? 'student',
  reputation: Number(r.reputation ?? 0),
  profileVisibility: r.profile_visibility ?? 'public',
  interests: r.interests ?? [],
  skills: r.skills ?? [],
  githubUrl: r.github_url ?? undefined,
  linkedinUrl: r.linkedin_url ?? undefined,
  leetcodeUrl: r.leetcode_url ?? undefined,
  hackerrankUrl: r.hackerrank_url ?? undefined,
  completedProjectsCount: r.completed_projects_count ?? 0,
  signupBonusAwarded: true,
  createdAt: r.created_at ?? '',
});

const profileToRow = (u: Partial<UserProfile>) => {
  const m: Record<string, unknown> = {};
  if (u.fullName !== undefined) m.full_name = u.fullName;
  if (u.avatarUrl !== undefined) m.avatar_url = u.avatarUrl;
  if (u.statusEmoji !== undefined) m.status_emoji = u.statusEmoji;
  if (u.college !== undefined) m.college = u.college;
  if (u.branch !== undefined) m.branch = u.branch;
  if (u.academicYear !== undefined) m.academic_year = u.academicYear;
  if (u.bio !== undefined) m.bio = u.bio;
  if (u.profileVisibility !== undefined) m.profile_visibility = u.profileVisibility;
  if (u.interests !== undefined) m.interests = u.interests;
  if (u.skills !== undefined) m.skills = u.skills;
  if ('githubUrl' in u) m.github_url = u.githubUrl || null;
  if ('linkedinUrl' in u) m.linkedin_url = u.linkedinUrl || null;
  if ('leetcodeUrl' in u) m.leetcode_url = u.leetcodeUrl || null;
  if ('hackerrankUrl' in u) m.hackerrank_url = u.hackerrankUrl || null;
  return m;
};

const relTime = (iso: string): string => {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'Just now';
  if (m < 60) return `${m} min${m > 1 ? 's' : ''} ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hour${h > 1 ? 's' : ''} ago`;
  const d = Math.floor(h / 24);
  return d === 1 ? 'Yesterday' : `${d} days ago`;
};

const projectFromRow = (r: any): Project => {
  const members = (r.project_members ?? []).map((m: any) => ({
    userId: m.user_id,
    name: '',
    avatarUrl: '',
    role: m.role,
    joinedAt: (m.joined_at ?? '').substring(0, 10),
  }));
  return {
    id: r.id,
    title: r.title,
    description: r.description ?? '',
    category: r.category ?? '',
    technologies: r.technologies ?? [],
    requiredSkills: r.required_skills ?? [],
    ownerId: r.owner_id,
    ownerName: '',
    members,
    status: r.status,
    progress: r.progress ?? 0,
    memberCount: members.length,
    maxMembers: r.max_members ?? 4,
    repoUrl: r.repo_url ?? undefined,
    coverImage: r.cover_image ?? undefined,
    lastUpdated: relTime(r.updated_at ?? r.created_at),
    createdAt: r.created_at,
  };
};

const postFromRow = (r: any): CommunityPost => ({
  id: r.id,
  authorId: r.author_id,
  authorName: '',
  authorAvatar: '',
  authorBranch: '',
  category: r.category,
  title: r.title,
  content: r.content ?? '',
  tags: r.tags ?? [],
  upvotes: (r.post_upvotes ?? []).length,
  commentCount: (r.post_comments ?? []).length,
  comments: (r.post_comments ?? [])
    .sort((a: any, b: any) => a.created_at.localeCompare(b.created_at))
    .map((c: any) => ({
      id: c.id,
      authorId: c.author_id,
      authorName: '',
      authorAvatar: '',
      content: c.content,
      createdAt: relTime(c.created_at),
    })),
  createdAt: relTime(r.created_at),
});

/** Resize + compress an image file to a square-ish JPEG blob (max 384px). */
const resizeImage = (file: File, max = 384): Promise<Blob> =>
  new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const side = Math.min(img.width, img.height);
      const sx = (img.width - side) / 2;
      const sy = (img.height - side) / 2;
      const size = Math.min(max, side);
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      canvas.getContext('2d')!.drawImage(img, sx, sy, side, side, 0, 0, size, size);
      URL.revokeObjectURL(url);
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('Could not process image'))), 'image/jpeg', 0.88);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('That file is not a valid image'));
    };
    img.src = url;
  });
/* eslint-enable @typescript-eslint/no-explicit-any */

const loadScoped = (uid: string) => ({
  credits: readJSON<number>(scoped(uid, 'credits'), 0),
  lifetimeEarned: readJSON<number>(scoped(uid, 'lifetime_earned'), 0),
  lifetimeSpent: readJSON<number>(scoped(uid, 'lifetime_spent'), 0),
  platforms: readJSON<PlatformConnection[] | null>(scoped(uid, 'platforms'), null),
  unlocked: readJSON<string[]>(scoped(uid, 'unlocked_questions'), []),
  transactions: readJSON<CreditTransaction[]>(scoped(uid, 'transactions'), []),
  history: readJSON<ActivityHistoryItem[]>(scoped(uid, 'history'), []),
  notifications: readJSON<NotificationItem[]>(scoped(uid, 'notifications'), []),
  registeredEvents: readJSON<string[]>(scoped(uid, 'registered_events'), []),
  upvotedPosts: readJSON<string[]>(scoped(uid, 'upvoted_posts'), []),
});

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // ----- Auth session & people (Supabase) ------------------------------------
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [dataError, setDataError] = useState<string | null>(null);

  const currentUser: UserProfile = useMemo(
    () => profiles.find((p) => p.id === sessionId) ?? GUEST_USER,
    [profiles, sessionId]
  );
  const isAuthenticated = currentUser.id !== '';
  const uid = currentUser.id;

  // ----- Theme ----------------------------------------------------------------
  const [theme, setThemeState] = useState<ThemeMode>(() =>
    document.documentElement.classList.contains('dark') ? 'dark' : 'light'
  );
  const setTheme = useCallback((t: ThemeMode) => {
    const root = document.documentElement;
    root.classList.add('theme-transition');
    root.classList.toggle('dark', t === 'dark');
    window.setTimeout(() => root.classList.remove('theme-transition'), 250);
    try {
      localStorage.setItem('peercraft_theme', t);
    } catch {
      /* ignore */
    }
    setThemeState(t);
  }, []);
  const toggleTheme = useCallback(() => setTheme(theme === 'dark' ? 'light' : 'dark'), [theme, setTheme]);

  // ----- Per-user state (re-loaded whenever the signed-in user changes) --------
  const initial = useMemo(() => loadScoped(uid), []); // eslint-disable-line react-hooks/exhaustive-deps
  const [availableCredits, setAvailableCredits] = useState<number>(initial.credits);
  const [lifetimeEarned, setLifetimeEarned] = useState<number>(initial.lifetimeEarned);
  const [lifetimeSpent, setLifetimeSpent] = useState<number>(initial.lifetimeSpent);
  const [platformConnections, setPlatformConnections] = useState<PlatformConnection[]>(
    () => initial.platforms ?? buildPlatforms(currentUser)
  );
  const [unlockedQuestionIds, setUnlockedQuestionIds] = useState<string[]>(initial.unlocked);
  const [transactions, setTransactions] = useState<CreditTransaction[]>(initial.transactions);
  const [history, setHistory] = useState<ActivityHistoryItem[]>(initial.history);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initial.notifications);
  const [registeredEventIds, setRegisteredEventIds] = useState<string[]>(initial.registeredEvents);

  // ----- Shared stores (visible to everyone using this browser) ----------------
  const [rawProjects, setProjects] = useState<Project[]>([]);
  const [codingQuestions, setCodingQuestions] = useState<CodingQuestion[]>(() =>
    readJSON('peercraft_questions', initialCodingQuestions)
  );
  const [resources, setResources] = useState<ResourceItem[]>(() => readJSON('peercraft_resources', initialResources));
  const [microGigs, setMicroGigs] = useState<MicroGig[]>(() => readJSON('peercraft_gigs', initialMicroGigs));
  const [rawEvents, setEvents] = useState<CampusEvent[]>(() => readJSON('peercraft_events', initialEvents));
  const [rawPosts, setCommunityPosts] = useState<CommunityPost[]>([]);
  const [myUpvotes, setMyUpvotes] = useState<string[]>([]);
  const [signupBonusAmount, setSignupBonusAmountState] = useState<number>(() =>
    readJSON<number>('peercraft_signup_bonus', 1000)
  );
  const [rewardRules, setRewardRules] = useState<RewardRule[]>(() => readJSON('peercraft_reward_rules', initialRewardRules));
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(() => readJSON('peercraft_audit_logs', []));

  // ----- People directory ---------------------------------------------------
  const allUsers: UserProfile[] = profiles;

  const userById = useMemo(() => new Map(allUsers.map((u) => [u.id, u])), [allUsers]);
  const getUserById = useCallback((id: string) => userById.get(id), [userById]);

  // Live-derived views: names/avatars always reflect the latest profile edits.
  const projects: Project[] = useMemo(
    () =>
      rawProjects.map((p) => {
        const owner = userById.get(p.ownerId);
        const mine = p.members.find((m) => m.userId === currentUser.id);
        return {
          ...p,
          ownerName: owner?.fullName ?? p.ownerName,
          members: p.members.map((m) => {
            const u = userById.get(m.userId);
            return u ? { ...m, name: u.fullName, avatarUrl: u.avatarUrl } : m;
          }),
          memberCount: p.members.length,
          isUserEnrolled: Boolean(mine),
          userRole: mine?.role,
        };
      }),
    [rawProjects, userById, currentUser.id]
  );

  const communityPosts: CommunityPost[] = useMemo(
    () =>
      rawPosts.map((post) => {
        const author = userById.get(post.authorId);
        return {
          ...post,
          authorName: author?.fullName ?? post.authorName,
          authorAvatar: author?.avatarUrl ?? post.authorAvatar,
          authorBranch: author ? `${author.branch} • ${author.academicYear}` : post.authorBranch,
          isUpvoted: myUpvotes.includes(post.id),
          comments: post.comments.map((c) => {
            const cu = c.authorId ? userById.get(c.authorId) : undefined;
            return cu ? { ...c, authorName: cu.fullName, authorAvatar: cu.avatarUrl } : c;
          }),
        };
      }),
    [rawPosts, userById, myUpvotes]
  );

  const events: CampusEvent[] = useMemo(
    () => rawEvents.map((e) => ({ ...e, isRegistered: registeredEventIds.includes(e.id) })),
    [rawEvents, registeredEventIds]
  );

  const otherPeoplesActiveProjects = useMemo(
    () =>
      projects
        .filter((p) => !p.isUserEnrolled && p.status !== 'Completed' && p.status !== 'On Hold')
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [projects]
  );

  // ----- AI Mentor state ----------------------------------------------------------
  const [aiMentorMode, setAiMentorMode] = useState<AIMentorMode>('Learn');
  const [isAiMentorOpen, setIsAiMentorOpen] = useState<boolean>(false);
  const [selectedQuestionContext, setSelectedQuestionContext] = useState<CodingQuestion | null>(null);
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);
  const welcomeMessage = (): AIMessage => ({
    id: 'ai_welcome',
    role: 'assistant',
    mode: 'Learn',
    content:
      "Hello! I am your PeerCraft AI Mentor. I can explain algorithms, give hints without spoilers, debug your edge cases, and find teammates: switch to Match mode and tell me the skills or keywords you need.",
    createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  });
  const [aiMessages, setAiMessages] = useState<AIMessage[]>([welcomeMessage()]);

  const [searchQuery, setSearchQuery] = useState('');

  // ----- Sidebar ---------------------------------------------------------------------
  const [isSidebarCollapsed, setIsSidebarCollapsedState] = useState<boolean>(
    () => localStorage.getItem('peercraft_sidebar_collapsed') === 'true'
  );
  const toggleSidebarCollapse = () => {
    setIsSidebarCollapsedState((prev) => {
      const next = !prev;
      localStorage.setItem('peercraft_sidebar_collapsed', next.toString());
      return next;
    });
  };
  const setSidebarCollapsed = (collapsed: boolean) => {
    setIsSidebarCollapsedState(collapsed);
    localStorage.setItem('peercraft_sidebar_collapsed', collapsed.toString());
  };

  // ----- Quick actions -------------------------------------------------------------------
  const [quickActions, setQuickActions] = useState<QuickActionItem[]>(() =>
    readJSON('peercraft_quick_actions', defaultQuickActions)
  );
  const reorderQuickActions = (newActions: QuickActionItem[]) => {
    setQuickActions(newActions);
    writeJSON('peercraft_quick_actions', newActions);
  };
  const moveQuickAction = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === quickActions.length - 1) return;
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    const updated = [...quickActions];
    const [moved] = updated.splice(index, 1);
    updated.splice(targetIndex, 0, moved);
    setQuickActions(updated);
    writeJSON('peercraft_quick_actions', updated);
  };
  const resetQuickActions = () => {
    setQuickActions(defaultQuickActions);
    writeJSON('peercraft_quick_actions', defaultQuickActions);
  };

  // ----- Avatar --------------------------------------------------------------------------------
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);

  // ----- Fullscreen ------------------------------------------------------------------------------
  const [isFullscreen, setIsFullscreen] = useState(false);
  useEffect(() => {
    const onFullscreenChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
  }, []);
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => {});
    else document.exitFullscreen().catch(() => {});
  };

  // ----- Persistence -------------------------------------------------------------------------------
  // Per-user data: only persist when someone is signed in.
  useEffect(() => {
    if (!uid) return;
    writeJSON(scoped(uid, 'credits'), availableCredits);
    writeJSON(scoped(uid, 'lifetime_earned'), lifetimeEarned);
    writeJSON(scoped(uid, 'lifetime_spent'), lifetimeSpent);
  }, [uid, availableCredits, lifetimeEarned, lifetimeSpent]);
  useEffect(() => { if (uid) writeJSON(scoped(uid, 'platforms'), platformConnections); }, [uid, platformConnections]);
  useEffect(() => { if (uid) writeJSON(scoped(uid, 'unlocked_questions'), unlockedQuestionIds); }, [uid, unlockedQuestionIds]);
  useEffect(() => { if (uid) writeJSON(scoped(uid, 'transactions'), transactions); }, [uid, transactions]);
  useEffect(() => { if (uid) writeJSON(scoped(uid, 'history'), history); }, [uid, history]);
  useEffect(() => { if (uid) writeJSON(scoped(uid, 'notifications'), notifications); }, [uid, notifications]);
  useEffect(() => { if (uid) writeJSON(scoped(uid, 'registered_events'), registeredEventIds); }, [uid, registeredEventIds]);

  useEffect(() => writeJSON('peercraft_questions', codingQuestions), [codingQuestions]);
  useEffect(() => writeJSON('peercraft_resources', resources), [resources]);
  useEffect(() => writeJSON('peercraft_gigs', microGigs), [microGigs]);
  useEffect(() => writeJSON('peercraft_events', rawEvents), [rawEvents]);
  useEffect(() => writeJSON('peercraft_signup_bonus', signupBonusAmount), [signupBonusAmount]);
  useEffect(() => writeJSON('peercraft_reward_rules', rewardRules), [rewardRules]);
  useEffect(() => writeJSON('peercraft_audit_logs', auditLogs), [auditLogs]);

  // ----- Supabase data loading ------------------------------------------------
  const refreshData = useCallback(async () => {
    const [pr, pj, po] = await Promise.all([
      supabase.from('profiles').select('*'),
      supabase.from('projects').select('*, project_members(*)').order('created_at', { ascending: false }),
      supabase
        .from('community_posts')
        .select('*, post_comments(*), post_upvotes(user_id)')
        .order('created_at', { ascending: false }),
    ]);
    const err = pr.error || pj.error || po.error;
    if (err) {
      setDataError(err.message);
      return;
    }
    setDataError(null);
    setProfiles((pr.data ?? []).map(profileFromRow));
    setProjects((pj.data ?? []).map(projectFromRow));
    setCommunityPosts((po.data ?? []).map(postFromRow));
    const me = (await supabase.auth.getSession()).data.session?.user.id;
    setMyUpvotes(
      (po.data ?? [])
        .filter((p: { post_upvotes?: { user_id: string }[] }) => (p.post_upvotes ?? []).some((u) => u.user_id === me))
        .map((p: { id: string }) => p.id)
    );
  }, []);

  /** Load another user's private (local) data into state on login/logout. */
  const hydrateScoped = (userId: string, u: UserProfile) => {
    // First time on this device: grant the welcome bonus as a real ledger entry.
    if (localStorage.getItem(scoped(userId, 'credits')) === null) {
      const now = new Date().toISOString();
      writeJSON(scoped(userId, 'credits'), signupBonusAmount);
      writeJSON(scoped(userId, 'lifetime_earned'), signupBonusAmount);
      writeJSON(scoped(userId, 'transactions'), [
        { id: `tx_${Date.now()}`, userId, transactionType: 'signup_bonus', amount: signupBonusAmount,
          description: 'Welcome bonus for joining PeerCraft', status: 'completed', createdAt: now },
      ]);
      writeJSON(scoped(userId, 'history'), [
        { id: `hist_${Date.now()}`, userId, eventType: 'credit_earned', category: 'Credits Earned',
          title: 'Joined PeerCraft', description: `Received ${signupBonusAmount.toLocaleString()} Campus Credits as a welcome bonus.`,
          timestamp: 'Just now', status: 'Completed', creditDelta: signupBonusAmount, linkUrl: '/credits' },
      ]);
    }
    const sc = loadScoped(userId);
    setAvailableCredits(sc.credits);
    setLifetimeEarned(sc.lifetimeEarned);
    setLifetimeSpent(sc.lifetimeSpent);
    setPlatformConnections(sc.platforms ?? buildPlatforms(u));
    setUnlockedQuestionIds(sc.unlocked);
    setTransactions(sc.transactions);
    setHistory(sc.history);
    setNotifications(sc.notifications);
    setRegisteredEventIds(sc.registeredEvents);
    setAiMessages([welcomeMessage()]);
  };

  // Restore session + react to sign-in / sign-out.
  useEffect(() => {
    let mounted = true;
    const apply = async (userId: string | null) => {
      if (!mounted) return;
      if (userId) {
        setSessionId(userId);
        await refreshData();
        // Safety net: if the DB trigger has not been installed, create the profile row ourselves.
        const { data: prof } = await supabase.from('profiles').select('id').eq('id', userId).maybeSingle();
        if (!prof) {
          const { data: au } = await supabase.auth.getUser();
          const meta = (au.user?.user_metadata ?? {}) as Record<string, string>;
          const name = meta.full_name || au.user?.email?.split('@')[0] || 'Student';
          await supabase.from('profiles').upsert({
            id: userId,
            email: au.user?.email ?? '',
            full_name: name,
            college: meta.college ?? '',
            branch: meta.branch ?? '',
            academic_year: meta.academic_year ?? '',
            avatar_url: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=26783c&textColor=ffffff`,
          });
          await refreshData();
        }
      } else {
        setSessionId(null);
        setProfiles([]);
        setProjects([]);
        setCommunityPosts([]);
      }
      if (mounted) setAuthReady(true);
    };
    supabase.auth.getSession().then(({ data }) => apply(data.session?.user.id ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, session) => {
      // Defer to avoid deadlocks inside the auth callback.
      setTimeout(() => apply(session?.user.id ?? null), 0);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, [refreshData]);

  // Once the profile row is available, load this user's private data.
  useEffect(() => {
    if (isAuthenticated) hydrateScoped(currentUser.id, currentUser);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser.id, isAuthenticated]);

  // Keep the feed fresh (other people's new projects/posts).
  useEffect(() => {
    if (!isAuthenticated) return;
    const t = window.setInterval(refreshData, 30000);
    const onFocus = () => refreshData();
    window.addEventListener('focus', onFocus);
    return () => {
      window.clearInterval(t);
      window.removeEventListener('focus', onFocus);
    };
  }, [isAuthenticated, refreshData]);

  // ----- Auth actions ---------------------------------------------------------------
  const register: AppContextType['register'] = async (input) => {
    const { data, error } = await supabase.auth.signUp({
      email: input.email.trim().toLowerCase(),
      password: input.password,
      options: {
        data: {
          full_name: input.fullName.trim().replace(/\s+/g, ' '),
          college: input.college,
          branch: input.branch,
          academic_year: input.academicYear,
          github_url: input.githubUrl ?? '',
          linkedin_url: input.linkedinUrl ?? '',
          leetcode_url: input.leetcodeUrl ?? '',
          hackerrank_url: input.hackerrankUrl ?? '',
        },
      },
    });
    if (error) return { ok: false, error: error.message };
    // With "Confirm email" enabled in Supabase there is no session until the link is clicked.
    if (!data.session) return { ok: true, needsEmailConfirmation: true };
    return { ok: true };
  };

  const login: AppContextType['login'] = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
    return error ? { ok: false, error: error.message } : { ok: true };
  };

  const logout = async () => {
    setIsAiMentorOpen(false);
    await supabase.auth.signOut();
  };

  /** Profile edits go to the `profiles` row, then every screen re-renders from that one source. */
  const updateUserProfile: AppContextType['updateUserProfile'] = async (updates) => {
    if (!uid) return { ok: false, error: 'Not signed in' };
    // optimistic local update
    setProfiles((prev) => prev.map((p) => (p.id === uid ? { ...p, ...updates } : p)));
    const { error } = await supabase.from('profiles').update(profileToRow(updates)).eq('id', uid);
    if (error) {
      await refreshData();
      return { ok: false, error: error.message };
    }
    if ('githubUrl' in updates || 'linkedinUrl' in updates || 'leetcodeUrl' in updates || 'hackerrankUrl' in updates) {
      setPlatformConnections((prev) => buildPlatforms({ ...currentUser, ...updates }, prev));
    }
    return { ok: true };
  };

  const updateAvatar = (avatarUrl: string, statusEmoji?: string) => {
    void updateUserProfile({ avatarUrl, ...(statusEmoji !== undefined ? { statusEmoji } : {}) });
    setShowAvatarPicker(false);
  };

  const uploadAvatar: AppContextType['uploadAvatar'] = async (file) => {
    if (!uid) return { ok: false, error: 'Not signed in' };
    if (!file.type.startsWith('image/')) return { ok: false, error: 'Please choose an image file.' };
    if (file.size > 10 * 1024 * 1024) return { ok: false, error: 'Image must be under 10 MB.' };
    try {
      const blob = await resizeImage(file);
      const path = `${uid}/avatar-${Date.now()}.jpg`;
      const { error } = await supabase.storage.from('avatars').upload(path, blob, {
        contentType: 'image/jpeg',
        upsert: true,
      });
      if (error) return { ok: false, error: error.message };
      const { data } = supabase.storage.from('avatars').getPublicUrl(path);
      const res = await updateUserProfile({ avatarUrl: data.publicUrl });
      return res;
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : 'Upload failed' };
    }
  };

  // Derived metrics
  // Enrolled active projects: only projects where isUserEnrolled is true and status !== 'Completed'
  const activeProjectsCount = projects.filter(
    (p) => p.isUserEnrolled && p.status !== 'Completed'
  ).length;

  const borrowedResourcesCount = resources.filter(
    (r) => r.borrowedByUserId === currentUser.id && r.availability === 'Borrowed'
  ).length;

  const unreadNotificationsCount = notifications.filter((n) => !n.isRead).length;

  // Add history helper
  const addHistoryItem = (item: Omit<ActivityHistoryItem, 'id' | 'timestamp' | 'userId'>) => {
    const newItem: ActivityHistoryItem = {
      ...item,
      id: `hist_${Date.now()}`,
      userId: currentUser.id,
      timestamp: 'Just now',
    };
    setHistory((prev) => [newItem, ...prev]);
  };

  // Add audit log helper
  const addAuditLog = (action: string, targetType: string, targetId: string, details: string) => {
    const newLog: AuditLogItem = {
      id: `audit_${Date.now()}`,
      adminId: currentUser.id,
      adminName: currentUser.fullName,
      action,
      targetType,
      targetId,
      details,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Platform reward claiming with daily cap check
  const claimPlatformReward = (platformKey: string, activityName: string, amount: number) => {
    const platform = platformConnections.find((p) => p.platform === platformKey);
    if (!platform) return { success: false, message: 'Platform not found.' };

    if (!platform.isConnected) {
      return { success: false, message: `Please connect your ${platform.displayName} profile first.` };
    }

    if (platform.creditsEarnedToday + amount > platform.dailyCap) {
      return {
        success: false,
        message: `Daily cap of ${platform.dailyCap} credits reached for ${platform.displayName}. You have already earned ${platform.creditsEarnedToday} credits today.`,
      };
    }

    // Atomic issuance
    setAvailableCredits((prev) => prev + amount);
    setLifetimeEarned((prev) => prev + amount);

    // Update platform record
    setPlatformConnections((prev) =>
      prev.map((p) =>
        p.platform === platformKey
          ? { ...p, creditsEarnedToday: p.creditsEarnedToday + amount, lastSyncAt: 'Just now' }
          : p
      )
    );

    // Create transaction record
    const newTx: CreditTransaction = {
      id: `tx_${Date.now()}`,
      userId: currentUser.id,
      transactionType: `reward_${platformKey}` as any,
      amount: amount,
      description: `Verified ${platform.displayName} reward: ${activityName}`,
      sourcePlatform: platform.displayName,
      referenceId: `verif_${Math.random().toString(36).substring(2, 9)}`,
      status: 'completed',
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [newTx, ...prev]);

    // Create history item
    addHistoryItem({
      eventType: 'credit_earned',
      category: 'Developer Platforms',
      title: `${platform.displayName} Contribution Reward`,
      description: `Earned ${amount} Campus Credits for verified ${activityName}.`,
      status: 'Verified',
      creditDelta: amount,
      linkUrl: '/credits/earn',
    });

    // Notify user
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: currentUser.id,
        type: 'credit_reward',
        title: `${platform.displayName} Reward Credited!`,
        message: `You earned +${amount} Campus Credits for ${activityName}.`,
        isRead: false,
        linkUrl: '/credits',
        createdAt: 'Just now',
      },
      ...prev,
    ]);

    return { success: true, message: `Successfully earned +${amount} Campus Credits!` };
  };

  const updatePlatformConnection = (platformKey: string, username: string, profileUrl: string) => {
    setPlatformConnections((prev) =>
      prev.map((p) =>
        p.platform === platformKey
          ? {
              ...p,
              username,
              profileUrl,
              isConnected: true,
              isVerified: true,
              lastSyncAt: 'Just now',
            }
          : p
      )
    );

    addHistoryItem({
      eventType: 'platform_connected',
      category: 'Developer Platforms',
      title: `Connected ${platformKey.toUpperCase()} Profile`,
      description: `Saved and linked verified developer profile @${username}.`,
      status: 'Completed',
      linkUrl: '/credits/earn',
    });
  };

  // Question unlocking flow
  const unlockQuestion = (questionId: string) => {
    const question = codingQuestions.find((q) => q.id === questionId);
    if (!question) {
      return { success: false, reason: 'Question not found' };
    }

    // If already unlocked, return existing entitlement with no re-charge!
    if (unlockedQuestionIds.includes(questionId)) {
      return { success: true, question };
    }

    const price = question.creditPrice;

    // Server-authoritative credit check
    if (availableCredits < price) {
      return { success: false, reason: 'insufficient_credits', question };
    }

    // Atomic debit
    setAvailableCredits((prev) => prev - price);
    setLifetimeSpent((prev) => prev + price);
    setUnlockedQuestionIds((prev) => [...prev, questionId]);

    // Create transaction
    const newTx: CreditTransaction = {
      id: `tx_${Date.now()}`,
      userId: currentUser.id,
      transactionType: 'unlock_question',
      amount: -price,
      description: `Unlocked curated link: ${question.title} (${question.platform})`,
      sourcePlatform: question.platform,
      referenceId: question.id,
      status: 'completed',
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [newTx, ...prev]);

    // Record in history
    addHistoryItem({
      eventType: 'question_unlocked',
      category: 'Coding Arena',
      title: `Unlocked Question Link: ${question.title}`,
      description: `Used ${price} Campus Credits to unlock curated link for ${question.title} on ${question.platform}.`,
      status: 'Completed',
      creditDelta: -price,
      linkUrl: '/coding-arena',
    });

    // Notify user
    setNotifications((prev) => [
      {
        id: `notif_${Date.now()}`,
        userId: currentUser.id,
        type: 'question_unlock',
        title: `Question Link Unlocked: ${question.title}`,
        message: `Unlocked curated link for ${question.title}. You can now practice on ${question.platform}.`,
        isRead: false,
        linkUrl: '/coding-arena',
        createdAt: 'Just now',
      },
      ...prev,
    ]);

    return { success: true, question };
  };

  const addCodingQuestion = (newQ: Omit<CodingQuestion, 'id' | 'createdAt'>) => {
    const question: CodingQuestion = {
      ...newQ,
      id: `q_${Date.now()}`,
      createdAt: new Date().toISOString().substring(0, 10),
    };
    setCodingQuestions((prev) => [question, ...prev]);
    addAuditLog('CREATE_QUESTION', 'CODING_QUESTION', question.id, `Published question "${question.title}" (${question.category}) with price ${question.creditPrice}`);
  };

  const updateCodingQuestion = (id: string, updates: Partial<CodingQuestion>) => {
    setCodingQuestions((prev) =>
      prev.map((q) => (q.id === id ? { ...q, ...updates } : q))
    );
    addAuditLog('UPDATE_QUESTION', 'CODING_QUESTION', id, `Updated details for question ${id}`);
  };

  const verifyQuestionLink = (id: string) => {
    const today = new Date().toISOString().substring(0, 10);
    setCodingQuestions((prev) =>
      prev.map((q) => (q.id === id ? { ...q, lastLinkVerifiedAt: today } : q))
    );
    addAuditLog('VERIFY_LINK', 'CODING_QUESTION', id, `Verified external destination link integrity`);
  };

  // Projects (Supabase)
  const createProject: AppContextType['createProject'] = (projectData) => {
    void (async () => {
      const { data, error } = await supabase
        .from('projects')
        .insert({
          title: projectData.title,
          description: projectData.description,
          category: projectData.category,
          technologies: projectData.technologies,
          required_skills: projectData.requiredSkills,
          owner_id: currentUser.id,
          status: projectData.status,
          progress: projectData.progress ?? 10,
          max_members: projectData.maxMembers,
          repo_url: projectData.repoUrl || null,
          cover_image: projectData.coverImage || null,
        })
        .select('id')
        .single();
      if (error || !data) {
        setDataError(error?.message ?? 'Could not create project');
        return;
      }
      await supabase
        .from('project_members')
        .insert({ project_id: data.id, user_id: currentUser.id, role: 'Project Lead' });
      await refreshData();
      addHistoryItem({
        eventType: 'project_created',
        category: 'Projects',
        title: `Created Project: ${projectData.title}`,
        description: 'Initialized project and enrolled as Project Lead.',
        status: 'Active',
        linkUrl: `/projects/${data.id}`,
      });
    })();
  };

  const joinProject = (projectId: string, role = 'Team Member') => {
    const project = projects.find((p) => p.id === projectId);
    void (async () => {
      const { error } = await supabase
        .from('project_members')
        .insert({ project_id: projectId, user_id: currentUser.id, role });
      if (error && !error.message.includes('duplicate')) {
        setDataError(error.message);
        return;
      }
      await refreshData();
      addHistoryItem({
        eventType: 'project_joined',
        category: 'Projects',
        title: `Joined Project: ${project?.title || 'Campus Project'}`,
        description: `Enrolled as ${role}.`,
        status: 'Active',
        linkUrl: `/projects/${projectId}`,
      });
    })();
  };

  // Resources
  const borrowResource = (resourceId: string) => {
    const res = resources.find((r) => r.id === resourceId);
    if (!res || res.availability !== 'Available') {
      return { success: false, message: 'Resource is currently not available.' };
    }

    setResources((prev) =>
      prev.map((r) =>
        r.id === resourceId
          ? {
              ...r,
              availability: 'Borrowed',
              borrowedByUserId: currentUser.id,
              borrowedAt: new Date().toISOString().substring(0, 10),
            }
          : r
      )
    );

    addHistoryItem({
      eventType: 'resource_borrowed',
      category: 'Resources',
      title: `Borrowed: ${res.name}`,
      description: `Resource borrowed from ${res.ownerName} for ${res.borrowingDuration}.`,
      status: 'Active',
      linkUrl: '/resources/history',
    });

    return { success: true, message: `Successfully requested ${res.name}!` };
  };

  const returnResource = (resourceId: string) => {
    const res = resources.find((r) => r.id === resourceId);
    if (!res) return { success: false, message: 'Resource not found' };

    setResources((prev) =>
      prev.map((r) =>
        r.id === resourceId
          ? {
              ...r,
              availability: 'Available',
              borrowedByUserId: undefined,
              borrowedAt: undefined,
            }
          : r
      )
    );

    addHistoryItem({
      eventType: 'milestone_completed',
      category: 'Resources',
      title: `Returned: ${res.name}`,
      description: `Item returned in good condition. Borrow record completed.`,
      status: 'Completed',
      linkUrl: '/resources',
    });

    return { success: true, message: `Successfully returned ${res.name}.` };
  };

  // Micro-gigs
  const applyToGig = (gigId: string) => {
    setMicroGigs((prev) =>
      prev.map((g) => (g.id === gigId ? { ...g, applicantsCount: g.applicantsCount + 1 } : g))
    );
    const gig = microGigs.find((g) => g.id === gigId);
    addHistoryItem({
      eventType: 'milestone_completed',
      category: 'Projects',
      title: `Applied to Micro-Gig: ${gig?.title}`,
      description: `Submitted proposal for ${gig?.rewardCredits} credits reward.`,
      status: 'Pending',
      linkUrl: '/micro-gigs',
    });
  };

  const createGig = (gig: Omit<MicroGig, 'id' | 'creatorId' | 'creatorName' | 'applicantsCount' | 'createdAt' | 'status'>) => {
    const newGig: MicroGig = {
      ...gig,
      id: `gig_${Date.now()}`,
      creatorId: currentUser.id,
      creatorName: currentUser.fullName,
      applicantsCount: 0,
      status: 'Open',
      createdAt: new Date().toISOString().substring(0, 10),
    };
    setMicroGigs((prev) => [newGig, ...prev]);
  };

  // Events
  const registerForEvent = (eventId: string) => {
    setRegisteredEventIds((prev) => (prev.includes(eventId) ? prev : [...prev, eventId]));
    const ev = rawEvents.find((e) => e.id === eventId);
    addHistoryItem({
      eventType: 'event_registered',
      category: 'Events',
      title: `Registered: ${ev?.title}`,
      description: `Confirmed participation for ${ev?.dateTime}.`,
      status: 'Completed',
      linkUrl: '/events',
    });
  };

  // Community (Supabase)
  const createCommunityPost: AppContextType['createCommunityPost'] = (title, content, category, tags) => {
    void (async () => {
      const { error } = await supabase
        .from('community_posts')
        .insert({ author_id: currentUser.id, title, content, category, tags });
      if (error) setDataError(error.message);
      await refreshData();
    })();
  };

  const togglePostUpvote = (postId: string) => {
    const has = myUpvotes.includes(postId);
    setMyUpvotes((prev) => (has ? prev.filter((i) => i !== postId) : [...prev, postId]));
    setCommunityPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, upvotes: Math.max(0, p.upvotes + (has ? -1 : 1)) } : p))
    );
    void (async () => {
      const q = has
        ? supabase.from('post_upvotes').delete().eq('post_id', postId).eq('user_id', currentUser.id)
        : supabase.from('post_upvotes').insert({ post_id: postId, user_id: currentUser.id });
      const { error } = await q;
      if (error) {
        setDataError(error.message);
        await refreshData();
      }
    })();
  };

  const addCommentToPost = (postId: string, text: string) => {
    void (async () => {
      const { error } = await supabase
        .from('post_comments')
        .insert({ post_id: postId, author_id: currentUser.id, content: text });
      if (error) setDataError(error.message);
      await refreshData();
    })();
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  // Admin rules
  const setSignupBonusAmount = (amount: number) => {
    setSignupBonusAmountState(amount);
    addAuditLog('SET_SIGNUP_BONUS', 'CONFIG', 'BONUS', `Updated signup bonus from default to ${amount} Campus Credits.`);
  };

  const updateRewardRule = (id: string, updates: Partial<RewardRule>) => {
    setRewardRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, ...updates, updatedAt: new Date().toISOString().substring(0, 10) } : r))
    );
    addAuditLog('UPDATE_REWARD_RULE', 'REWARD_RULE', id, `Updated reward parameters for ${id}`);
  };

  // AI Mentor messaging with mode-specific reasoning
  const sendAiMessage = (messageText: string) => {
    if (!messageText.trim()) return;
    if (aiMentorMode === 'Match') {
      findPeerMatches({ text: messageText, branch: 'Any', year: 'Any', minProficiency: 'Any', verifiedOnly: false });
      return;
    }

    const userMsg: AIMessage = {
      id: `ai_${Date.now()}`,
      role: 'user',
      content: messageText,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setAiMessages((prev) => [...prev, userMsg]);
    setIsAiThinking(true);

    // Realistic intelligent assistant response generation
    setTimeout(() => {
      let replyContent = '';
      const qContext = selectedQuestionContext ? `regarding "${selectedQuestionContext.title}"` : '';

      if (aiMentorMode === 'Learn') {
        replyContent = `### Concept Breakdown ${qContext}\n\n` +
          `Let's analyze the underlying pattern:\n\n` +
          `1. **Problem Core:** This problem evaluates your understanding of algorithmic trade-offs (space vs. time complexity).\n` +
          `2. **Key Intuition:** Instead of a brute-force approach (often $O(N^2)$), think about how storing intermediate states in an auxiliary hash map or two-pointer window reduces unnecessary computations to $O(N)$.\n` +
          `3. **Step-by-Step Logic:**\n` +
          `   - **Step 1:** Initialize pointers or frequency maps.\n` +
          `   - **Step 2:** Iterate while maintaining invariant conditions.\n` +
          `   - **Step 3:** Evaluate candidate solutions on-the-fly.\n\n` +
          `*Question for you:* Have you considered what happens if the input has duplicate values or negative numbers?`;
      } else if (aiMentorMode === 'Hint') {
        replyContent = `### Progressive Hint ${qContext}\n\n` +
          `💡 **Hint 1 of 3:**\n` +
          `Notice how sorting the input array or utilizing a hash map transforms lookups from linear time to constant time $O(1)$.\n\n` +
          `> *Key Question to consider:* Can you traverse the array once and check if the complement \`(target - current)\` was already encountered?\n\n` +
          `Let me know if you would like **Hint 2** (focusing on edge cases and memory bounds).`;
      } else {
        // Debug mode
        replyContent = `### Debugging Analysis ${qContext}\n\n` +
          `Here is what to look out for in your implementation:\n\n` +
          `1. **Boundary & Off-by-one errors:** Ensure while-loop conditions use \`<= \` or \`< \` according to inclusive/exclusive index semantics.\n` +
          `2. **Empty or Single-element checks:** Handle \`len == 0\` or \`len == 1\` upfront to prevent NullPointer or IndexOutOfBounds exceptions.\n` +
          `3. **Time Complexity:** Optimal target is typically **$O(N)$ time** and **$O(N)$ auxiliary space**.\n\n` +
          `If you paste your exact code snippet, I can identify the specific line failing tests.`;
      }

      const assistantMsg: AIMessage = {
        id: `ai_resp_${Date.now()}`,
        role: 'assistant',
        mode: aiMentorMode,
        content: replyContent,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setAiMessages((prev) => [...prev, assistantMsg]);
      setIsAiThinking(false);
    }, 800);
  };

  const findPeerMatches = (query: MatchQuery) => {
    const summary = [
      query.text.trim() && `“${query.text.trim()}”`,
      query.branch !== 'Any' && query.branch,
      query.year !== 'Any' && query.year,
      query.minProficiency !== 'Any' && `${query.minProficiency}+ level`,
      query.verifiedOnly && 'verified skills only',
    ].filter(Boolean).join(' • ') || 'No preferences (top peers)';
    setAiMessages((prev) => [
      ...prev,
      {
        id: `ai_${Date.now()}`,
        role: 'user',
        content: `Find me teammates: ${summary}`,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setIsAiThinking(true);
    window.setTimeout(() => {
      const candidates = allUsers.filter((u) => u.id !== currentUser.id);
      const matches = matchPeers(query, candidates, projects, collectVocabulary(candidates, projects)).slice(0, 6);
      const content =
        matches.length > 0
          ? `I found ${matches.length} suitable ${matches.length === 1 ? 'profile' : 'profiles'} for ${summary}. Ranked by skill match, proficiency, verification and reputation:`
          : candidates.length === 0
          ? 'No other students have joined yet. Invite your classmates and I will match them as soon as they sign up.'
          : `I could not find anyone matching ${summary}. Try fewer keywords, a related skill (e.g. "frontend" instead of "React 19"), or relax the branch/year/level filters.`;
      setAiMessages((prev) => [
        ...prev,
        {
          id: `ai_resp_${Date.now()}`,
          role: 'assistant',
          mode: 'Match',
          content,
          matches,
          createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      setIsAiThinking(false);
    }, 600);
  };

  const clearAiMessages = () => {
    setAiMessages([welcomeMessage()]);
  };

  const resetAllLocalData = () => {
    Object.keys(localStorage)
      .filter((k) => k.startsWith('peercraft') && k !== 'peercraft_theme')
      .forEach((k) => localStorage.removeItem(k));
    window.location.href = '/';
  };

  return (
    <AppContext.Provider
      value={{
        currentUser, isAuthenticated, authReady, register, login, logout, allUsers, getUserById,
        updateUserProfile, uploadAvatar, refreshData, dataError,
        theme, toggleTheme, setTheme,
        availableCredits, lifetimeEarned, lifetimeSpent, transactions, history, addHistoryItem,
        platformConnections, updatePlatformConnection, claimPlatformReward,
        codingQuestions, unlockedQuestionIds, unlockQuestion, addCodingQuestion, updateCodingQuestion, verifyQuestionLink,
        projects, otherPeoplesActiveProjects, activeProjectsCount, createProject, joinProject,
        resources, borrowedResourcesCount, borrowResource, returnResource,
        microGigs, applyToGig, createGig,
        events, registerForEvent,
        communityPosts, createCommunityPost, togglePostUpvote, addCommentToPost,
        notifications, unreadNotificationsCount, markNotificationAsRead, markAllNotificationsAsRead,
        signupBonusAmount, setSignupBonusAmount, rewardRules, updateRewardRule, auditLogs, addAuditLog,
        aiMessages, aiMentorMode, setAiMentorMode, isAiMentorOpen, setIsAiMentorOpen,
        selectedQuestionContext, setSelectedQuestionContext, sendAiMessage, findPeerMatches, clearAiMessages, isAiThinking,
        searchQuery, setSearchQuery,
        isSidebarCollapsed, toggleSidebarCollapse, setSidebarCollapsed,
        quickActions, reorderQuickActions, moveQuickAction, resetQuickActions,
        showAvatarPicker, setShowAvatarPicker, updateAvatar,
        isFullscreen, toggleFullscreen,
        resetAllLocalData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
