import React, { useState } from 'react';
import { useNavigate, useLocation, Link, Navigate } from 'react-router-dom';
import { ArrowRight, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LogoMark } from '../components/brand/Logo';
import { ThemeToggle } from '../components/ui/ThemeToggle';

export const LoginPage: React.FC = () => {
  const { login, isAuthenticated, authReady } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from || '/dashboard';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (authReady && isAuthenticated) return <Navigate to="/dashboard" replace />;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);
    const res = await login(email, password);
    setIsLoading(false);
    if (!res.ok) {
      setErrorMsg(res.error ?? 'Could not sign in.');
      return;
    }
    navigate(from, { replace: true });
  };

  return (
    <div className="min-h-screen bg-pc-main text-pc-body flex items-center justify-center p-4 sm:p-6 relative">
      <div className="absolute top-4 right-4 w-36">
        <ThemeToggle variant="page" />
      </div>
      <div className="max-w-md w-full bg-pc-card rounded-card border border-pc-line shadow-card p-6 sm:p-8 space-y-6">
        <div className="text-center space-y-2">
          <LogoMark size={48} className="mx-auto drop-shadow-sm" />
          <h1 className="text-2xl font-black text-pc-ink tracking-tight">Sign in to PeerCraft</h1>
          <p className="text-xs text-pc-muted">
            Access your campus projects, credits wallet and team workspaces.
          </p>
        </div>

        {errorMsg && (
          <div className="bg-pc-error/10 border border-pc-error/30 text-pc-error p-3 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-pc-ink mb-1">Email</label>
            <input
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
            />
          </div>

          <div>
            <label className="block font-bold text-pc-ink mb-1">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-3 pr-8 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-pc-muted"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 bg-[#26783C] hover:bg-[#1C622F] disabled:opacity-50 text-white font-bold rounded-btn transition-colors shadow-xs text-xs flex items-center justify-center gap-1.5"
          >
            <span>{isLoading ? 'Signing in…' : 'Sign In'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-pc-muted">
          Don't have an account yet?{' '}
          <Link to="/signup" className="font-bold text-pc-accent hover:underline">
            Create one & claim your welcome credits
          </Link>
        </div>
      </div>
    </div>
  );
};
