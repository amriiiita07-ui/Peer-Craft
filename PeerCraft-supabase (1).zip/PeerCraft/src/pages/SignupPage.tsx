import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Coins,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LogoMark } from '../components/brand/Logo';

export const SignupPage: React.FC = () => {
  const { register, signupBonusAmount } = useApp();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [college, setCollege] = useState('');
  const [branch, setBranch] = useState('');
  const [academicYear, setAcademicYear] = useState('Third Year');
  const [githubUrl, setGithubUrl] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [leetcodeUrl, setLeetcodeUrl] = useState('');
  const [hackerrankUrl, setHackerrankUrl] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);

  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showRewardModal, setShowRewardModal] = useState(false);
  const [confirmEmailSent, setConfirmEmailSent] = useState(false);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!termsAccepted) {
      setErrorMsg('Please accept the campus community terms and conditions.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match. Please re-enter.');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    setIsLoading(true);
    const res = await register({
      fullName,
      email,
      password,
      college,
      branch,
      academicYear,
      githubUrl,
      linkedinUrl,
      leetcodeUrl,
      hackerrankUrl,
    });
    setIsLoading(false);

    if (!res.ok) {
      setErrorMsg(res.error ?? 'Could not create your account.');
      return;
    }
    if (res.needsEmailConfirmation) {
      setConfirmEmailSent(true);
      return;
    }
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#26783C', '#EFC66B', '#E4EDCF', '#173D2A'],
    });
    setShowRewardModal(true);
  };

  const handleExplorePlatform = () => {
    setShowRewardModal(false);
    navigate('/onboarding');
  };

  return (
    <div className="min-h-screen bg-pc-main text-pc-body flex items-center justify-center p-4 sm:p-6">
      <div className="max-w-xl w-full bg-pc-card rounded-card border border-pc-line shadow-card p-6 sm:p-8 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-1.5">
          <LogoMark size={44} className="mx-auto drop-shadow-sm" />
          <h1 className="text-2xl font-black text-pc-ink tracking-tight">
            Create Your PeerCraft Account
          </h1>
          <p className="text-xs text-pc-muted">
            Join your college engineering cohort & claim your 1,000 Campus Credits reward.
          </p>
        </div>

        {confirmEmailSent && (
          <div className="bg-pc-accent/10 border border-pc-accent/30 text-pc-accent p-3 rounded-xl text-xs">
            Account created! Check <strong>{email}</strong> for a confirmation link, then <Link to="/login" className="underline font-bold">sign in</Link>.
          </div>
        )}

        {errorMsg && (
          <div className="bg-[#D94A4A]/10 border border-[#D94A4A]/30 text-pc-error p-3 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSignup} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-bold text-pc-ink mb-1">Full Name</label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Your full name"
                className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-pc-ink mb-1">College Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@college.edu"
                className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-bold text-pc-ink mb-1">College / University</label>
              <input
                type="text"
                required
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-pc-ink mb-1">Academic Branch</label>
              <input
                type="text"
                required
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
                placeholder="Computer Science Engineering"
                className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-pc-ink mb-1">Year of Study</label>
            <select
              value={academicYear}
              onChange={(e) => setAcademicYear(e.target.value)}
              className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line rounded-input text-pc-body outline-none"
            >
              <option value="First Year">First Year</option>
              <option value="Second Year">Second Year</option>
              <option value="Third Year">Third Year</option>
              <option value="Final Year">Final Year</option>
              <option value="Postgraduate">Postgraduate</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-bold text-pc-ink mb-1">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full pl-3 pr-8 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-pc-muted"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block font-bold text-pc-ink mb-1">Confirm Password</label>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-type password"
                className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body outline-none"
              />
            </div>
          </div>

          <div className="space-y-2 pt-1 border-t border-pc-line">
            <div className="text-[11px] font-bold text-pc-ink">
              Optional Developer Profiles (Can link later in Earn Credits)
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <input
                type="url"
                value={githubUrl}
                onChange={(e) => setGithubUrl(e.target.value)}
                placeholder="GitHub Profile URL"
                className="px-2.5 py-1.5 bg-pc-secondary/40 border border-pc-line rounded text-pc-body outline-none"
              />
              <input
                type="url"
                value={leetcodeUrl}
                onChange={(e) => setLeetcodeUrl(e.target.value)}
                placeholder="LeetCode Profile URL"
                className="px-2.5 py-1.5 bg-pc-secondary/40 border border-pc-line rounded text-pc-body outline-none"
              />
            </div>
          </div>

          <label className="flex items-start gap-2 cursor-pointer pt-2">
            <input
              type="checkbox"
              checked={termsAccepted}
              onChange={(e) => setTermsAccepted(e.target.checked)}
              className="mt-0.5 text-pc-accent"
            />
            <span className="text-[11px] text-pc-muted">
              I agree to the PeerCraft Code of Conduct, Academic Integrity Guidelines, and Campus Terms of Service.
            </span>
          </label>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 bg-[#26783C] hover:bg-[#1C622F] disabled:opacity-50 text-white font-bold rounded-btn transition-colors shadow-xs text-xs"
          >
            {isLoading ? 'Creating Account & Verifying Bonus...' : 'Register & Claim 1,000 Credits'}
          </button>
        </form>

        <div className="text-center text-xs text-pc-muted">
          Already have an account?{' '}
          <Link to="/login" className="font-bold text-pc-accent hover:underline">
            Sign In
          </Link>
        </div>
      </div>

      {/* Mandatory Welcome Reward Modal from Section 5 */}
      {showRewardModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-pc-card rounded-card border-2 border-[#26783C] p-6 sm:p-8 max-w-md w-full shadow-2xl text-center space-y-5 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-pc-highlight text-pc-accent flex items-center justify-center mx-auto shadow-subtle border border-[#26783C]/30">
              <Coins className="w-8 h-8 text-[#EFC66B] fill-[#EFC66B] animate-bounce" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-black text-pc-ink tracking-tight">
                Welcome to PeerCraft!
              </h2>
              <p className="text-sm font-medium text-pc-accent leading-relaxed">
                "You've received {signupBonusAmount.toLocaleString()} credits to start building your campus journey."
              </p>
              <p className="text-xs text-pc-muted">
                These credits have been added to your wallet ledger. You can use them to unlock curated premium coding question links or collaborate on projects.
              </p>
            </div>

            <div className="p-3 bg-pc-secondary rounded-xl text-xs text-pc-ink font-semibold flex items-center justify-center gap-2">
              <ShieldCheck className="w-4 h-4 text-pc-accent" />
              <span>Available Wallet Balance: {signupBonusAmount} Credits</span>
            </div>

            <button
              onClick={handleExplorePlatform}
              className="w-full py-3 bg-[#26783C] hover:bg-[#1C622F] text-white font-extrabold text-sm rounded-btn transition-colors shadow-card flex items-center justify-center gap-2"
            >
              <span>Explore PeerCraft</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
