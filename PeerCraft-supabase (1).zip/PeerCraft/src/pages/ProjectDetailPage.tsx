import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  FolderKanban,
  ArrowLeft,
  Users,
  CheckCircle2,
  Circle,
  ExternalLink,
  GitBranch,
  Calendar,
  Share2,
  UserPlus,
  Clock,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ProjectDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { projects, currentUser, joinProject } = useApp();
  const navigate = useNavigate();

  const project = projects.find((p) => p.id === id) || projects[0];

  const [milestones, setMilestones] = useState([
    { id: 'm1', title: 'System Architecture & Database Schema Design', done: true },
    { id: 'm2', title: 'Core API Endpoints & Auth Integration', done: true },
    { id: 'm3', title: 'Frontend UI Components & State Management', done: project.progress > 50 },
    { id: 'm4', title: 'Campus Beta Deployment & Field Testing', done: false },
    { id: 'm5', title: 'Performance Optimization & Final Documentation', done: false },
  ]);

  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [inviteStatus, setInviteStatus] = useState<string | null>(null);

  const toggleMilestone = (milestoneId: string) => {
    setMilestones((prev) =>
      prev.map((m) => (m.id === milestoneId ? { ...m, done: !m.done } : m))
    );
  };

  const isEnrolled = project.members.some((m) => m.userId === currentUser.id);

  const handleJoin = () => {
    joinProject(project.id, 'Contributor');
  };

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setInviteModalOpen(false);
    setInviteStatus('Invitation sent to campus teammate!');
    setTimeout(() => setInviteStatus(null), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Toast */}
      {inviteStatus && (
        <div className="bg-[#26783C] text-white px-4 py-2.5 rounded-lg text-xs font-semibold shadow-card flex items-center justify-between">
          <span>{inviteStatus}</span>
          <button onClick={() => setInviteStatus(null)}>✕</button>
        </div>
      )}

      {/* Back button */}
      <div>
        <Link
          to="/projects"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-pc-accent hover:underline mb-2"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Project Workspace
        </Link>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-pc-accent bg-pc-secondary px-2.5 py-0.5 rounded-full">
                {project.category}
              </span>
              <span className="text-xs text-pc-muted font-medium">Status: {project.status}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-pc-ink tracking-tight">
              {project.title}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            {!isEnrolled ? (
              <button
                onClick={handleJoin}
                className="px-4 py-2 bg-[#26783C] hover:bg-[#1C622F] text-white text-xs font-bold rounded-btn transition-colors shadow-xs"
              >
                Join Project Team
              </button>
            ) : (
              <button
                onClick={() => setInviteModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-pc-forest hover:bg-pc-deep text-white text-xs font-bold rounded-btn transition-colors shadow-xs"
              >
                <UserPlus className="w-4 h-4 text-[#EFC66B]" />
                <span>Invite Teammate</span>
              </button>
            )}

            {project.repoUrl && (
              <a
                href={project.repoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 border border-pc-line hover:bg-pc-secondary text-pc-ink text-xs font-semibold rounded-btn transition-colors"
              >
                <GitBranch className="w-4 h-4 text-pc-accent" />
                <span>Repository</span>
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left column: Overview, Milestones, Activity (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Overview */}
          <div className="bg-pc-card p-6 rounded-card border border-pc-line shadow-subtle space-y-4">
            <h2 className="text-base font-bold text-pc-ink">Project Overview</h2>
            <p className="text-xs sm:text-sm text-pc-muted leading-relaxed">
              {project.description}
            </p>

            <div>
              <div className="text-xs font-bold text-pc-ink mb-2">Technologies & Architecture</div>
              <div className="flex flex-wrap gap-1.5">
                {project.technologies.map((t, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2.5 py-1 rounded bg-pc-secondary text-pc-ink font-semibold"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs font-bold text-pc-ink mb-2">Required Core Skills</div>
              <div className="flex flex-wrap gap-1.5">
                {project.requiredSkills.map((s, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2.5 py-1 rounded border border-pc-line bg-pc-card text-pc-muted"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Tasks & Milestones */}
          <div className="bg-pc-card p-6 rounded-card border border-pc-line shadow-subtle space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-pc-ink">Milestones & Deliverables</h2>
                <p className="text-xs text-pc-muted">Check off deliverables as tasks complete.</p>
              </div>
              <span className="text-xs font-bold text-pc-accent bg-pc-secondary px-2.5 py-1 rounded-full">
                {milestones.filter((m) => m.done).length} / {milestones.length} Completed
              </span>
            </div>

            <div className="space-y-2">
              {milestones.map((milestone) => (
                <div
                  key={milestone.id}
                  onClick={() => toggleMilestone(milestone.id)}
                  className={`p-3 rounded-xl border transition-colors cursor-pointer flex items-center justify-between gap-3 text-xs ${
                    milestone.done
                      ? 'bg-pc-secondary/70 border-pc-line text-pc-ink'
                      : 'bg-pc-card hover:bg-pc-hover border-pc-line text-pc-muted'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {milestone.done ? (
                      <CheckCircle2 className="w-4 h-4 text-pc-accent flex-shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-[#A2BA95] flex-shrink-0" />
                    )}
                    <span className={milestone.done ? 'line-through text-pc-muted' : 'font-medium'}>
                      {milestone.title}
                    </span>
                  </div>
                  <span className="text-[10px] text-[#A2BA95] flex-shrink-0">
                    {milestone.done ? 'Verified' : 'Pending'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right column: Team Directory, Details (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Team Directory */}
          <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-pc-ink flex items-center gap-2">
                <Users className="w-4 h-4 text-pc-accent" />
                Team Directory
              </h2>
              <span className="text-xs text-pc-muted">
                {project.memberCount} / {project.maxMembers}
              </span>
            </div>

            <div className="space-y-3">
              {project.members.map((member) => (
                <div
                  key={member.userId}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-pc-secondary/50 border border-pc-line"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={member.avatarUrl}
                      alt={member.name}
                      className="w-8 h-8 rounded-full object-cover border border-[#26783C]/30"
                    />
                    <div>
                      <div className="font-bold text-xs text-pc-ink">{member.name}</div>
                      <div className="text-[10px] text-pc-muted">{member.role}</div>
                    </div>
                  </div>
                  <span className="text-[10px] text-[#A2BA95]">Joined {member.joinedAt}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Project Meta Details */}
          <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-3 text-xs">
            <h3 className="font-bold text-sm text-pc-ink">Initiative Meta</h3>
            <div className="space-y-2 text-pc-muted">
              <div className="flex justify-between">
                <span>Owner:</span>
                <span className="font-semibold text-pc-ink">{project.ownerName}</span>
              </div>
              <div className="flex justify-between">
                <span>Created:</span>
                <span>{new Date(project.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Last Updated:</span>
                <span>{project.lastUpdated}</span>
              </div>
              <div className="flex justify-between">
                <span>Your Enrolled Role:</span>
                <span className="font-bold text-pc-accent">
                  {project.userRole || (isEnrolled ? 'Team Member' : 'Not Enrolled')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Invite Modal */}
      {inviteModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-pc-card rounded-card border border-pc-line p-6 max-w-md w-full shadow-card text-pc-body space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-pc-line">
              <div className="font-bold text-base text-pc-ink flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-pc-accent" />
                Invite Campus Student
              </div>
              <button
                onClick={() => setInviteModalOpen(false)}
                className="text-pc-muted hover:text-pc-ink font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleInviteSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-pc-ink mb-1">
                  Student Campus Email or Username
                </label>
                <input
                  type="text"
                  required
                  placeholder="teammate@college.edu"
                  className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line rounded-input text-pc-body outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-pc-ink mb-1">Proposed Role</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Frontend Specialist"
                  className="w-full px-3 py-2 bg-pc-secondary/50 border border-pc-line rounded-input text-pc-body outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setInviteModalOpen(false)}
                  className="px-4 py-2 border border-pc-line text-pc-muted hover:bg-pc-secondary rounded-btn font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#26783C] hover:bg-[#1C622F] text-white rounded-btn font-bold"
                >
                  Send Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
