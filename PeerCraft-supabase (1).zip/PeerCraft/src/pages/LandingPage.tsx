import React from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles,
  ArrowRight,
  FolderKanban,
  Code2,
  Coins,
  BadgeCheck,
  UsersRound,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

import { Logo } from '../components/brand/Logo';
import { ThemeToggle } from '../components/ui/ThemeToggle';

export const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-pc-main text-pc-body flex flex-col">
      {/* Navbar */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-pc-line bg-pc-card/90 backdrop-blur-md sticky top-0 z-30">
        <Logo size={38} />

        <div className="flex items-center gap-3">
          <ThemeToggle compact variant="page" />
          <Link
            to="/login"
            className="px-4 py-2 text-xs font-bold text-pc-ink hover:text-pc-accent transition-colors"
          >
            Sign In
          </Link>
          <Link
            to="/signup"
            className="px-4 py-2 bg-[#26783C] hover:bg-[#1C622F] text-white text-xs font-bold rounded-btn transition-colors shadow-xs"
          >
            Get Started (+1,000 Credits)
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-6 pt-16 pb-20 text-center space-y-6 flex-1 flex flex-col justify-center items-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pc-secondary text-pc-ink text-xs font-bold border border-pc-line">
          <span className="w-2 h-2 rounded-full bg-[#26783C] animate-pulse" />
          The Modern Campus Collaboration & Developer Growth Platform
        </div>

        <h1 className="text-4xl sm:text-6xl font-black text-pc-ink tracking-tight max-w-4xl leading-tight">
          Where College Developers{' '}
          <span className="text-pc-accent underline decoration-[#EFC66B] decoration-4 underline-offset-8">
            Build, Collaborate & Grow
          </span>
        </h1>

        <p className="text-base sm:text-lg text-pc-muted max-w-2xl leading-relaxed mx-auto">
          Create multidisciplinary project teams, earn platform credits through verified GitHub and LeetCode activity, unlock curated coding links, and establish your verified skill passport.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-3 pt-4">
          <Link
            to="/signup"
            className="px-6 py-3.5 bg-[#26783C] hover:bg-[#1C622F] text-white text-sm font-extrabold rounded-btn transition-all shadow-card flex items-center gap-2 hover:scale-102"
          >
            <span>Claim 1,000 Signup Credits</span>
            <ArrowRight className="w-4 h-4" />
          </Link>

          <Link
            to="/dashboard"
            className="px-6 py-3.5 bg-pc-card hover:bg-pc-hover border border-pc-line text-pc-ink text-sm font-bold rounded-btn transition-colors shadow-subtle"
          >
            Explore Interactive Demo
          </Link>
        </div>

        {/* Feature Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-16 text-left w-full">
          <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-2">
            <div className="w-9 h-9 rounded-lg bg-pc-secondary text-pc-accent flex items-center justify-center">
              <FolderKanban className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-pc-ink">Active Project Workspace</h3>
            <p className="text-xs text-pc-muted leading-relaxed">
              Track enrolled team milestones, manage contributors, and log verified deliverables.
            </p>
          </div>

          <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-2">
            <div className="w-9 h-9 rounded-lg bg-pc-secondary text-[#EFC66B] flex items-center justify-center">
              <Coins className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-pc-ink">Verified Credit Economy</h3>
            <p className="text-xs text-pc-muted leading-relaxed">
              Earn Campus Credits for qualifying pull requests and solved challenges on LeetCode.
            </p>
          </div>

          <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-2">
            <div className="w-9 h-9 rounded-lg bg-pc-secondary text-pc-accent flex items-center justify-center">
              <Code2 className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-pc-ink">Curated Coding Arena</h3>
            <p className="text-xs text-pc-muted leading-relaxed">
              Discover free practice links or unlock curated premium question links for 100 credits.
            </p>
          </div>

          <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-2">
            <div className="w-9 h-9 rounded-lg bg-pc-secondary text-pc-accent flex items-center justify-center">
              <BadgeCheck className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-pc-ink">Verified Skill Passport</h3>
            <p className="text-xs text-pc-muted leading-relaxed">
              Showcase tamper-proof technical proficiencies and verified peer reputation scores.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-pc-line bg-pc-card px-6 py-6 text-center text-xs text-pc-muted">
        <div className="font-bold text-pc-ink">PeerCraft — Build • Collaborate • Grow</div>
        <p className="mt-1">
          Designed for college students, engineering clubs, and hackathon teams.
        </p>
      </footer>
    </div>
  );
};
