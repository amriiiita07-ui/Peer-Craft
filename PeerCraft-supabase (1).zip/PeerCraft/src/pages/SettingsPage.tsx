import React, { useState } from 'react';
import {
  Settings,
  Shield,
  Bell,
  Lock,
  Eye,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Save,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ThemeToggle } from '../components/ui/ThemeToggle';

export const SettingsPage: React.FC = () => {
  const { currentUser, resetAllLocalData } = useApp();

  const [emailNotifs, setEmailNotifs] = useState(true);
  const [projectAlerts, setProjectAlerts] = useState(true);
  const [creditAlerts, setCreditAlerts] = useState(true);
  const [visibility, setVisibility] = useState(currentUser.profileVisibility);
  const [confirmResetModal, setConfirmResetModal] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const handleSavePreferences = (e: React.FormEvent) => {
    e.preventDefault();
    setToastMsg('Settings updated successfully!');
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleConfirmReset = () => {
    resetAllLocalData();
    setConfirmResetModal(false);
    setToastMsg('All application state restored to default demo state!');
    setTimeout(() => setToastMsg(null), 3500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Toast */}
      {toastMsg && (
        <div className="bg-[#26783C] text-white px-4 py-2.5 rounded-lg text-xs font-semibold shadow-card flex items-center justify-between">
          <span>{toastMsg}</span>
          <button onClick={() => setToastMsg(null)}>✕</button>
        </div>
      )}

      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pc-secondary text-pc-ink text-xs font-semibold mb-2">
          <Settings className="w-3.5 h-3.5 text-pc-accent" />
          Platform Preferences
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-pc-ink tracking-tight">
          Settings
        </h1>
        <p className="text-sm text-pc-muted mt-1">
          Configure security, notifications, profile privacy, and local data persistence.
        </p>
      </div>

      <form onSubmit={handleSavePreferences} className="space-y-6 text-xs">
        {/* Account & Profile Privacy */}
        <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-4">
          <h2 className="text-sm font-bold text-pc-ink flex items-center gap-2 border-b border-pc-line pb-2">
            <Eye className="w-4 h-4 text-pc-accent" />
            Profile Visibility & Campus Privacy
          </h2>

          <div className="space-y-3">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="radio"
                name="visibility"
                checked={visibility === 'public'}
                onChange={() => setVisibility('public')}
                className="mt-0.5 text-pc-accent"
              />
              <div>
                <div className="font-bold text-pc-ink">Public (Recommended)</div>
                <div className="text-[11px] text-pc-muted">
                  Visible to all campus teammates, project owners, and external public link viewers.
                </div>
              </div>
            </label>

            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="radio"
                name="visibility"
                checked={visibility === 'campus_only'}
                onChange={() => setVisibility('campus_only')}
                className="mt-0.5 text-pc-accent"
              />
              <div>
                <div className="font-bold text-pc-ink">Campus Only</div>
                <div className="text-[11px] text-pc-muted">
                  Only authenticated college peers with verified @campus.edu emails can view.
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* Notifications Preferences */}
        <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-4">
          <h2 className="text-sm font-bold text-pc-ink flex items-center gap-2 border-b border-pc-line pb-2">
            <Bell className="w-4 h-4 text-pc-accent" />
            Notification Preferences
          </h2>

          <div className="space-y-3">
            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <div className="font-bold text-pc-ink">Campus Credit Rewards Alerts</div>
                <div className="text-[11px] text-pc-muted">
                  Notify immediately when GitHub commits or LeetCode challenges yield credits.
                </div>
              </div>
              <input
                type="checkbox"
                checked={creditAlerts}
                onChange={(e) => setCreditAlerts(e.target.checked)}
                className="w-4 h-4 text-pc-accent"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <div className="font-bold text-pc-ink">Project Invitations & Updates</div>
                <div className="text-[11px] text-pc-muted">
                  Receive alerts when someone invites you to a project or updates milestones.
                </div>
              </div>
              <input
                type="checkbox"
                checked={projectAlerts}
                onChange={(e) => setProjectAlerts(e.target.checked)}
                className="w-4 h-4 text-pc-accent"
              />
            </label>
          </div>
        </div>

        {/* Security & Password */}
        <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-4">
          <h2 className="text-sm font-bold text-pc-ink flex items-center gap-2 border-b border-pc-line pb-2">
            <Lock className="w-4 h-4 text-pc-accent" />
            Authentication & Security
          </h2>

          <div className="space-y-2">
            <div className="text-pc-muted">
              Signed in as: <strong className="text-pc-ink">{currentUser.email}</strong>
            </div>
            <div className="text-[11px] text-pc-accent font-semibold">
              ✓ Multi-factor authentication protected via Campus SSO
            </div>
          </div>
        </div>

        {/* Save button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#26783C] hover:bg-[#1C622F] text-white rounded-btn font-bold transition-colors shadow-xs"
          >
            Save Settings
          </button>
        </div>
      </form>

      {/* Appearance */}
      <div className="bg-pc-card p-5 rounded-card border border-pc-line shadow-subtle space-y-3">
        <h2 className="text-sm font-bold text-pc-ink">Appearance</h2>
        <p className="text-xs text-pc-muted">Switch between light and dark mode. Your choice is remembered on this device.</p>
        <div className="w-44"><ThemeToggle variant="page" /></div>
      </div>

      {/* Demo Reset / Danger Zone */}
      <div className="bg-pc-card p-5 rounded-card border border-[#D94A4A]/30 shadow-subtle space-y-3">
        <h2 className="text-sm font-bold text-pc-error flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          Clear Data On This Device
        </h2>
        <p className="text-xs text-pc-muted leading-relaxed">
          Clears credits, history, notifications and preferences saved in this browser. Your account, profile and projects stay safe in Supabase.
        </p>
        <button
          onClick={() => setConfirmResetModal(true)}
          className="px-4 py-2 border border-[#D94A4A] text-pc-error hover:bg-[#D94A4A]/10 rounded-btn text-xs font-bold transition-colors"
        >
          Clear Local Data
        </button>
      </div>

      {/* Confirm Reset Modal */}
      {confirmResetModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-pc-card rounded-card border border-pc-line p-6 max-w-md w-full shadow-card text-pc-body space-y-4">
            <div className="flex items-center gap-2 text-pc-error font-bold text-base pb-2 border-b border-pc-line">
              <AlertTriangle className="w-5 h-5" />
              Confirm Clear Local Data
            </div>
            <p className="text-xs text-pc-muted leading-relaxed">
              Are you sure? This clears wallet balance, activity history and notifications stored in this browser.
            </p>
            <div className="pt-2 flex justify-end gap-2 text-xs">
              <button
                onClick={() => setConfirmResetModal(false)}
                className="px-4 py-2 border border-pc-line text-pc-muted hover:bg-pc-secondary rounded-btn font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReset}
                className="px-4 py-2 bg-[#D94A4A] hover:bg-[#b83b3b] text-white rounded-btn font-bold"
              >
                Yes, Reset Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
