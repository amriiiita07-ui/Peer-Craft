import React from 'react';
import { Link } from 'react-router-dom';
import {
  Bell,
  Coins,
  FolderKanban,
  Code2,
  Package,
  Calendar,
  CheckCircle2,
  CheckCheck,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const NotificationsPage: React.FC = () => {
  const { notifications, markNotificationAsRead, markAllNotificationsAsRead } = useApp();

  const getIcon = (type: string) => {
    switch (type) {
      case 'credit_reward':
        return <Coins className="w-4 h-4 text-[#EFC66B]" />;
      case 'project_invite':
        return <FolderKanban className="w-4 h-4 text-pc-accent" />;
      case 'question_unlock':
        return <Code2 className="w-4 h-4 text-pc-ink" />;
      case 'resource_request':
        return <Package className="w-4 h-4 text-pc-accent" />;
      case 'event_reminder':
        return <Calendar className="w-4 h-4 text-pc-ink" />;
      default:
        return <Bell className="w-4 h-4 text-pc-muted" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pc-secondary text-pc-ink text-xs font-semibold mb-2">
            <Bell className="w-3.5 h-3.5 text-pc-accent" />
            Activity Alerts
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-pc-ink tracking-tight">
            Notifications
          </h1>
          <p className="text-sm text-pc-muted mt-1">
            Real-time updates regarding project invites, verified credits, and question unlocks.
          </p>
        </div>

        <button
          onClick={markAllNotificationsAsRead}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-pc-line hover:bg-pc-secondary text-pc-ink text-xs font-semibold rounded-btn transition-colors"
        >
          <CheckCheck className="w-3.5 h-3.5 text-pc-accent" />
          <span>Mark All Read</span>
        </button>
      </div>

      {/* Notifications List */}
      <div className="bg-pc-card rounded-card border border-pc-line shadow-subtle p-4 divide-y divide-pc-line/60">
        {notifications.length === 0 ? (
          <div className="py-12 text-center text-pc-muted space-y-2">
            <Bell className="w-8 h-8 mx-auto opacity-40 text-pc-ink" />
            <div className="font-semibold text-sm text-pc-ink">No notifications yet</div>
            <p className="text-xs">You're all caught up on campus events!</p>
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => markNotificationAsRead(n.id)}
              className={`p-3.5 rounded-xl transition-colors flex items-start justify-between gap-3 cursor-pointer ${
                !n.isRead ? 'bg-pc-secondary/70 font-medium' : 'hover:bg-pc-hover'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-pc-card border border-pc-line flex items-center justify-center flex-shrink-0 mt-0.5">
                  {getIcon(n.type)}
                </div>
                <div>
                  <div className="font-bold text-xs text-pc-ink">{n.title}</div>
                  <div className="text-xs text-pc-muted mt-0.5">{n.message}</div>
                  <div className="text-[10px] text-[#A2BA95] mt-1">{n.createdAt}</div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                {!n.isRead && (
                  <span className="w-2 h-2 rounded-full bg-[#26783C]" title="Unread" />
                )}
                {n.linkUrl && (
                  <Link
                    to={n.linkUrl}
                    className="p-1 rounded text-pc-muted hover:text-pc-ink"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Link>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
