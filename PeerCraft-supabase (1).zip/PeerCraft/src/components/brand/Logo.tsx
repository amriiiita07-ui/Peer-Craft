import React, { useId } from 'react';

interface LogoMarkProps {
  size?: number;
  className?: string;
}

/**
 * PeerCraft mark: two overlapping "peer" circles whose intersection is the
 * crafted result (gold lens), on a green tile.
 */
export const LogoMark: React.FC<LogoMarkProps> = ({ size = 36, className = '' }) => {
  const uid = useId().replace(/:/g, '');
  const gradId = `pc-grad-${uid}`;
  const clipId = `pc-clip-${uid}`;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      className={className}
      role="img"
      aria-label="PeerCraft"
    >
      <defs>
        <linearGradient id={gradId} x1="4" y1="2" x2="36" y2="38" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#34A04F" />
          <stop offset="1" stopColor="#14382A" />
        </linearGradient>
        <clipPath id={clipId}>
          <circle cx="15.2" cy="20" r="8.2" />
        </clipPath>
      </defs>
      <rect width="40" height="40" rx="11" fill={`url(#${gradId})`} />
      <circle cx="24.8" cy="20" r="8.2" fill="#EFC66B" clipPath={`url(#${clipId})`} />
      <circle cx="15.2" cy="20" r="8.2" fill="none" stroke="#F3F7EA" strokeWidth="2.4" />
      <circle cx="24.8" cy="20" r="8.2" fill="none" stroke="#F3F7EA" strokeWidth="2.4" />
    </svg>
  );
};

interface LogoProps {
  size?: number;
  showTagline?: boolean;
  collapsed?: boolean;
  /** Use light text (for dark backgrounds such as the sidebar). */
  onDark?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ size = 36, showTagline = true, collapsed = false, onDark = false }) => (
  <div className="flex items-center gap-2.5 overflow-hidden">
    <LogoMark size={size} className="flex-shrink-0" />
    {!collapsed && (
      <div className="overflow-hidden">
        <div
          className={`font-extrabold text-base tracking-tight whitespace-nowrap ${
            onDark ? 'text-white' : 'text-pc-ink'
          }`}
        >
          PeerCraft
        </div>
        {showTagline && (
          <div
            className={`text-[10px] font-medium tracking-wide whitespace-nowrap ${
              onDark ? 'text-[#A2BA95]' : 'text-pc-muted'
            }`}
          >
            Build • Collaborate • Grow
          </div>
        )}
      </div>
    )}
  </div>
);
