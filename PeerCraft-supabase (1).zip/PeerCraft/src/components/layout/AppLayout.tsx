import React, { useState } from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Sidebar } from './Sidebar';
import { TopNavbar } from './TopNavbar';
import { MobileNav } from './MobileNav';
import { PeerCraftAIMentor } from '../ai/PeerCraftAIMentor';
import { AvatarPickerModal } from '../modals/AvatarPickerModal';

export const AppLayout: React.FC = () => {
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const { isAuthenticated, authReady, dataError } = useApp();
  const location = useLocation();

  if (!authReady) {
    return (
      <div className="min-h-screen bg-pc-main flex items-center justify-center text-pc-muted text-sm">
        Loading PeerCraft…
      </div>
    );
  }
  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  return (
    <div className="min-h-screen bg-pc-main text-pc-body flex w-full overflow-x-clip">
      {/* Desktop Fixed Left Sidebar */}
      <div className="hidden lg:block sticky top-0 h-screen self-start flex-shrink-0 z-30">
        <Sidebar />
      </div>

      {/* Mobile Drawer Backdrop & Sidebar */}
      {mobileDrawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-in fade-in"
            onClick={() => setMobileDrawerOpen(false)}
          />
          <div className="relative z-10 w-[260px] h-full shadow-2xl animate-in slide-in-from-left">
            <Sidebar onCloseMobile={() => setMobileDrawerOpen(false)} />
          </div>
        </div>
      )}

      {/* Main Content Area - Fluid Full Screen */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen w-full">
        <TopNavbar onToggleMobileMenu={() => setMobileDrawerOpen(true)} />

        {dataError && (
          <div className="mx-4 mt-3 rounded-lg border border-pc-error/40 bg-pc-error/10 px-3 py-2 text-xs text-pc-error">
            Could not sync with Supabase: {dataError}. Did you run <code className="font-mono">supabase/schema.sql</code>?
          </div>
        )}
        <main className="flex-1 pb-20 lg:pb-8 w-full">
          <Outlet />
        </main>

        {/* Mobile Navigation bar */}
        <MobileNav onOpenDrawer={() => setMobileDrawerOpen(true)} />

        {/* Integrated AI Mentor floating assistant */}
        <PeerCraftAIMentor />

        {/* Interactive Avatar Picker Modal */}
        <AvatarPickerModal />
      </div>
    </div>
  );
};
