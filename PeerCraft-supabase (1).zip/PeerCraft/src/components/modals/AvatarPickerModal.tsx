import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Check,
  Sparkles,
  Camera,
  Upload,
  Smile,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { avatarPresets } from '../../data/mockData';

export const AvatarPickerModal: React.FC = () => {
  const { currentUser, showAvatarPicker, setShowAvatarPicker, updateAvatar, uploadAvatar, updateUserProfile } = useApp();

  const [selectedUrl, setSelectedUrl] = useState(currentUser.avatarUrl);
  const [selectedStatus, setSelectedStatus] = useState(currentUser.statusEmoji || '⚡ Coding');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [customUrl, setCustomUrl] = useState('');

  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Re-sync the draft whenever the dialog is opened.
  useEffect(() => {
    if (showAvatarPicker) {
      setSelectedUrl(currentUser.avatarUrl);
      setSelectedStatus(currentUser.statusEmoji || '⚡ Coding');
      setUploadError(null);
    }
  }, [showAvatarPicker, currentUser.avatarUrl, currentUser.statusEmoji]);

  if (!showAvatarPicker) return null;

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setUploadError(null);
    setUploading(true);
    const res = await uploadAvatar(file);
    setUploading(false);
    if (!res.ok) {
      setUploadError(res.error ?? 'Upload failed');
      return;
    }
    await updateUserProfile({ statusEmoji: selectedStatus });
    setShowAvatarPicker(false);
  };

  const categories = ['All', '3D Modern', 'Campus Tech', 'Illustrated', 'Anime Dev'];
  const statusOptions = [
    '⚡ Coding',
    '🚀 Shipping',
    '☕ Brainstorming',
    '📚 In Library',
    '🎯 Hackathon Mode',
    '🔬 In Lab',
  ];

  const filteredPresets = avatarPresets.filter(
    (p) => activeCategory === 'All' || p.category === activeCategory
  );

  const handleApply = () => {
    updateAvatar(selectedUrl, selectedStatus);
  };

  const handleApplyCustom = () => {
    if (customUrl.trim()) {
      setSelectedUrl(customUrl.trim());
      updateAvatar(customUrl.trim(), selectedStatus);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-pc-card rounded-card border-2 border-pc-line p-6 max-w-xl w-full shadow-2xl text-pc-body space-y-5 my-8">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-pc-line">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-pc-secondary text-pc-accent flex items-center justify-center">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-pc-ink leading-tight">
                Profile Photo & Status
              </h2>
              <p className="text-[11px] text-pc-muted">
                Upload your photo or pick an avatar, and set your status.
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowAvatarPicker(false)}
            className="p-1 rounded text-pc-muted hover:text-pc-ink hover:bg-pc-secondary"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Preview Card */}
        <div className="bg-gradient-to-r from-pc-secondary to-pc-highlight/60 p-4 rounded-xl border border-pc-line flex items-center gap-4">
          <div className="relative">
            <img
              src={selectedUrl}
              alt="Avatar Preview"
              className="w-16 h-16 rounded-full object-cover ring-4 ring-[#26783C] shadow-subtle bg-pc-card"
            />
            <span
              className="absolute -bottom-1 -right-1 text-sm bg-pc-forest text-white p-0.5 px-1 rounded-full border border-white shadow-xs"
              title="Status Emoji"
            >
              {selectedStatus.split(' ')[0]}
            </span>
          </div>
          <div>
            <div className="font-bold text-sm text-pc-ink flex items-center gap-1.5">
              <span>{currentUser.fullName}</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-pc-forest text-[#E4EDCF]">
                {selectedStatus}
              </span>
            </div>
            <div className="text-[11px] text-pc-muted">
              {currentUser.branch} • {currentUser.academicYear}
            </div>
            <div className="text-[10px] text-pc-accent font-semibold mt-0.5 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Campus Verified
            </div>
          </div>
        </div>

        {/* Upload your own photo */}
        <div className="rounded-xl border border-dashed border-pc-line bg-pc-secondary/40 p-3 flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex-1">
            <div className="text-xs font-bold text-pc-ink flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5 text-pc-accent" /> Upload your own photo
            </div>
            <p className="text-[11px] text-pc-muted mt-0.5">
              JPG, PNG or WebP up to 10 MB. It is cropped to a square and shown everywhere in PeerCraft.
            </p>
            {uploadError && <p className="text-[11px] text-pc-error mt-1">{uploadError}</p>}
          </div>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
          <button
            type="button"
            disabled={uploading}
            onClick={() => fileRef.current?.click()}
            className="px-3.5 py-2 bg-[#26783C] hover:bg-[#1C622F] disabled:opacity-50 text-white rounded-btn text-xs font-bold whitespace-nowrap"
          >
            {uploading ? 'Uploading…' : 'Choose photo'}
          </button>
        </div>

        {/* Status Emoji Selector */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-pc-ink">
            Current Activity / Campus Status:
          </label>
          <div className="flex flex-wrap gap-1.5">
            {statusOptions.map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => setSelectedStatus(status)}
                className={`text-xs px-2.5 py-1 rounded-full font-medium transition-all ${
                  selectedStatus === status
                    ? 'bg-pc-forest text-white shadow-xs font-bold'
                    : 'bg-pc-secondary/70 hover:bg-pc-highlight text-pc-body border border-pc-line'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-1 border-b border-pc-line pb-2 text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded-lg font-semibold transition-colors ${
                activeCategory === cat
                  ? 'bg-[#26783C] text-white'
                  : 'text-pc-muted hover:bg-pc-secondary'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Avatars Grid */}
        <div className="grid grid-cols-4 sm:grid-cols-6 gap-3 max-h-56 overflow-y-auto p-1 hide-scrollbar">
          {filteredPresets.map((preset) => {
            const isSelected = selectedUrl === preset.url;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => setSelectedUrl(preset.url)}
                className={`relative rounded-xl p-1.5 flex flex-col items-center gap-1 transition-all ${
                  isSelected
                    ? 'ring-2 ring-[#26783C] bg-pc-secondary scale-105'
                    : 'hover:bg-pc-secondary/50 border border-transparent'
                }`}
              >
                <img
                  src={preset.url}
                  alt={preset.name}
                  className="w-12 h-12 rounded-full object-cover bg-pc-card border border-pc-line"
                />
                <span className="text-[9px] font-medium text-pc-body text-center truncate w-full">
                  {preset.name}
                </span>
                {isSelected && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#26783C] text-white flex items-center justify-center text-[9px]">
                    <Check className="w-2.5 h-2.5" />
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Custom URL Input */}
        <div className="pt-2 border-t border-pc-line space-y-1.5 text-xs">
          <label className="block font-semibold text-pc-ink">Or Paste Custom Image URL:</label>
          <div className="flex gap-2">
            <input
              type="url"
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
              placeholder="https://..."
              className="flex-1 px-3 py-1.5 bg-pc-secondary/40 border border-pc-line rounded-input text-pc-body outline-none text-xs font-mono"
            />
            <button
              type="button"
              onClick={handleApplyCustom}
              disabled={!customUrl.trim()}
              className="px-3 py-1.5 bg-pc-forest disabled:opacity-40 text-white rounded-btn font-semibold hover:bg-pc-deep text-xs whitespace-nowrap"
            >
              Use Link
            </button>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-pc-line flex justify-end gap-2 text-xs">
          <button
            type="button"
            onClick={() => setShowAvatarPicker(false)}
            className="px-4 py-2 border border-pc-line text-pc-muted hover:bg-pc-secondary rounded-btn font-semibold"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleApply}
            className="px-5 py-2 bg-[#26783C] hover:bg-[#1C622F] text-white rounded-btn font-bold shadow-xs flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" /> Save Avatar
          </button>
        </div>
      </div>
    </div>
  );
};
