import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  UsersRound,
  FolderKanban,
  Package,
  Wallet,
  UserCheck,
  Calendar,
  GripVertical,
  ChevronLeft,
  ChevronRight,
  Move,
  RotateCcw,
  Check,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { QuickActionItem } from '../../types';

export const MovableQuickActions: React.FC = () => {
  const { quickActions, moveQuickAction, resetQuickActions } = useApp();
  const [isReordering, setIsReordering] = useState(false);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  const getActionIcon = (name: string) => {
    switch (name) {
      case 'UsersRound':
        return <UsersRound className="w-4 h-4" />;
      case 'FolderKanban':
        return <FolderKanban className="w-4 h-4" />;
      case 'Package':
        return <Package className="w-4 h-4" />;
      case 'Wallet':
        return <Wallet className="w-4 h-4" />;
      case 'UserCheck':
        return <UserCheck className="w-4 h-4" />;
      case 'Calendar':
        return <Calendar className="w-4 h-4" />;
      default:
        return <Sparkles className="w-4 h-4" />;
    }
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIndex(index);
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === targetIndex) return;

    // Move in appropriate direction
    if (draggedIndex < targetIndex) {
      for (let i = draggedIndex; i < targetIndex; i++) {
        moveQuickAction(i, 'down');
      }
    } else {
      for (let i = draggedIndex; i > targetIndex; i--) {
        moveQuickAction(i, 'up');
      }
    }
    setDraggedIndex(null);
  };

  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-pc-ink flex items-center gap-2">
            Quick Actions
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-pc-secondary text-pc-accent">
              Movable
            </span>
          </h2>
          <p className="text-xs text-pc-muted">Rapid campus navigation shortcuts.</p>
        </div>

        <div className="flex items-center gap-1.5 text-xs">
          {isReordering ? (
            <>
              <button
                onClick={resetQuickActions}
                className="px-2 py-1 rounded-lg border border-pc-line bg-pc-card hover:bg-pc-secondary text-pc-muted hover:text-pc-ink font-medium flex items-center gap-1 text-[11px]"
                title="Reset to default arrangement"
              >
                <RotateCcw className="w-3 h-3" /> Reset
              </button>
              <button
                onClick={() => setIsReordering(false)}
                className="px-2.5 py-1 rounded-lg bg-[#26783C] text-white font-bold flex items-center gap-1 text-[11px]"
              >
                <Check className="w-3 h-3" /> Done
              </button>
            </>
          ) : (
            <button
              onClick={() => setIsReordering(true)}
              className="px-2.5 py-1 rounded-lg border border-pc-line bg-pc-card hover:bg-pc-secondary text-pc-ink font-semibold flex items-center gap-1 text-[11px] transition-colors"
              title="Customize position of quick actions"
            >
              <Move className="w-3 h-3 text-pc-accent" /> Reorder
            </button>
          )}
        </div>
      </div>

      {/* Grid of 6 Quick Actions */}
      <div className="grid grid-cols-2 gap-2.5">
        {quickActions.map((action, idx) => {
          return (
            <div
              key={action.id}
              draggable={isReordering}
              onDragStart={(e) => handleDragStart(e, idx)}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, idx)}
              className={`p-3 rounded-card border transition-all relative flex flex-col justify-between ${
                isReordering
                  ? 'bg-pc-secondary/90 border-dashed border-[#26783C] cursor-grab active:cursor-grabbing shadow-xs'
                  : 'bg-pc-card hover:bg-pc-hover border-pc-line hover:border-[#26783C]/40 group'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-7 h-7 rounded-lg bg-pc-secondary text-pc-accent flex items-center justify-center group-hover:scale-105 transition-transform">
                  {getActionIcon(action.iconName)}
                </div>

                {/* Move Controls if in Reordering mode */}
                {isReordering ? (
                  <div className="flex items-center gap-0.5 bg-pc-card rounded-md border border-pc-line p-0.5">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => moveQuickAction(idx, 'up')}
                      className="p-1 hover:bg-pc-secondary disabled:opacity-30 rounded text-pc-ink"
                      title="Move backward"
                    >
                      <ChevronLeft className="w-3 h-3" />
                    </button>
                    <GripVertical className="w-3 h-3 text-pc-muted" />
                    <button
                      type="button"
                      disabled={idx === quickActions.length - 1}
                      onClick={() => moveQuickAction(idx, 'down')}
                      className="p-1 hover:bg-pc-secondary disabled:opacity-30 rounded text-pc-ink"
                      title="Move forward"
                    >
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <span className="text-[10px] text-[#A2BA95] font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                    #{idx + 1}
                  </span>
                )}
              </div>

              {/* Title & Desc */}
              {isReordering ? (
                <div>
                  <div className="font-bold text-xs text-pc-ink leading-tight">
                    {action.title}
                  </div>
                  <div className="text-[10px] text-pc-muted leading-tight mt-0.5">
                    {action.desc}
                  </div>
                </div>
              ) : (
                <Link to={action.to} className="block">
                  <div className="font-bold text-xs text-pc-ink group-hover:text-pc-accent transition-colors leading-tight">
                    {action.title}
                  </div>
                  <div className="text-[10px] text-pc-muted leading-tight mt-0.5">
                    {action.desc}
                  </div>
                </Link>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
