import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface Props {
  compact?: boolean;
  /** Use on pages with a normal (non-sidebar) background. */
  variant?: 'sidebar' | 'page';
}

export const ThemeToggle: React.FC<Props> = ({ compact = false, variant = 'sidebar' }) => {
  const { theme, toggleTheme } = useApp();
  const isDark = theme === 'dark';
  const label = isDark ? 'Switch to light mode' : 'Switch to dark mode';

  const style =
    variant === 'sidebar'
      ? 'bg-[#173D2A]/70 hover:bg-[#173D2A] text-[#E4EDCF] border border-[#26783C]/40'
      : 'bg-pc-card hover:bg-pc-secondary text-pc-ink border border-pc-line';

  return (
    <button
      type="button"
      onClick={toggleTheme}
      title={label}
      aria-label={label}
      className={`flex items-center justify-center gap-2 rounded-lg transition-colors text-xs font-semibold ${style} ${
        compact ? 'w-9 h-9' : 'w-full py-1.5 px-2'
      }`}
    >
      {isDark ? <Sun className="w-4 h-4 text-[#EFC66B]" /> : <Moon className="w-4 h-4" />}
      {!compact && <span>{isDark ? 'Light mode' : 'Dark mode'}</span>}
    </button>
  );
};
