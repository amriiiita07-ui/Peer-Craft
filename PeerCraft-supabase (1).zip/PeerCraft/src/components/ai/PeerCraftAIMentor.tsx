import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Bot,
  X,
  Send,
  Trash2,
  HelpCircle,
  Lightbulb,
  Bug,
  GraduationCap,
  Copy,
  Check,
  Maximize2,
  Minimize2,
  FileCode,
  UsersRound,
  Search,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { MatchQuery } from '../../types';

export const PeerCraftAIMentor: React.FC = () => {
  const {
    aiMessages,
    aiMentorMode,
    setAiMentorMode,
    isAiMentorOpen,
    setIsAiMentorOpen,
    selectedQuestionContext,
    setSelectedQuestionContext,
    sendAiMessage,
    clearAiMessages,
    isAiThinking,
    findPeerMatches,
    getUserById,
    allUsers,
    currentUser,
  } = useApp();

  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Match-mode preferences
  const [kw, setKw] = useState('');
  const [branch, setBranch] = useState('Any');
  const [year, setYear] = useState('Any');
  const [level, setLevel] = useState<MatchQuery['minProficiency']>('Any');
  const [verifiedOnly, setVerifiedOnly] = useState(false);

  const branchOptions = ['Any', ...Array.from(new Set(allUsers.filter((u) => u.id !== currentUser.id).map((u) => u.branch).filter(Boolean)))];
  const yearOptions = ['Any', ...Array.from(new Set(allUsers.filter((u) => u.id !== currentUser.id).map((u) => u.academicYear).filter(Boolean)))];

  const runMatch = (e?: React.FormEvent) => {
    e?.preventDefault();
    findPeerMatches({ text: kw, branch, year, minProficiency: level, verifiedOnly });
  };

  const suggestedPrompts = [
    'Explain this problem in simple terms',
    'Give me a hint without revealing the solution',
    'Help me find the optimal approach',
    'Explain time and space complexity',
    'Help debug my code',
    'Walk me through an example',
  ];

  const matchPrompts = [
    'UI/UX designer who knows Figma',
    'Python and machine learning',
    'Embedded C and IoT',
    'Flutter mobile developer',
  ];

  useEffect(() => {
    if (isAiMentorOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [aiMessages, isAiMentorOpen, isAiThinking]);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    sendAiMessage(inputText);
    setInputText('');
  };

  const handlePromptClick = (prompt: string) => {
    sendAiMessage(prompt);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!isAiMentorOpen) {
    return (
      <button
        onClick={() => setIsAiMentorOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-pc-forest hover:bg-pc-deep text-white p-3.5 rounded-full shadow-lg border border-[#E4EDCF]/40 flex items-center gap-2.5 transition-all duration-200 group hover:scale-105"
        title="Open PeerCraft AI Mentor"
      >
        <div className="relative">
          <Bot className="w-5 h-5 text-[#E4EDCF]" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#EFC66B] rounded-full animate-ping" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#EFC66B] rounded-full" />
        </div>
        <span className="text-xs font-bold tracking-tight pr-1 hidden sm:inline">
          AI Mentor
        </span>
      </button>
    );
  }

  return (
    <div
      className={`fixed z-50 bg-pc-card border border-pc-line rounded-2xl shadow-2xl flex flex-col transition-all duration-300 overflow-hidden ${
        isExpanded
          ? 'inset-4 md:inset-10'
          : 'bottom-4 right-4 md:bottom-6 md:right-6 w-[95vw] md:w-[420px] h-[580px] max-h-[85vh]'
      }`}
    >
      {/* Header */}
      <div className="bg-pc-forest text-white p-3.5 flex items-center justify-between border-b border-pc-deep">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#26783C] flex items-center justify-center text-[#EFC66B]">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-sm leading-tight flex items-center gap-1.5">
              PeerCraft AI Mentor
              <span className="text-[9px] uppercase font-semibold px-1.5 py-0.5 rounded bg-[#26783C] text-[#E4EDCF]">
                {aiMentorMode} Mode
              </span>
            </div>
            <div className="text-[10px] text-[#A2BA95] leading-tight">
              Coding help and teammate matching.
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[#A2BA95]">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 hover:text-white hover:bg-pc-deep rounded"
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={clearAiMessages}
            className="p-1 hover:text-white hover:bg-pc-deep rounded"
            title="Clear Chat"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsAiMentorOpen(false)}
            className="p-1 hover:text-white hover:bg-pc-deep rounded ml-1"
            title="Close Assistant"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mode Selector Tabs */}
      <div className="bg-pc-secondary px-3 py-1.5 flex items-center justify-between text-xs border-b border-pc-line">
        <span className="text-[11px] font-semibold text-pc-ink flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-pc-accent" /> Mode:
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setAiMentorMode('Learn')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
              aiMentorMode === 'Learn'
                ? 'bg-pc-forest text-white shadow-xs'
                : 'text-pc-body hover:bg-pc-line'
            }`}
          >
            <GraduationCap className="w-3 h-3" /> Learn
          </button>
          <button
            onClick={() => setAiMentorMode('Hint')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
              aiMentorMode === 'Hint'
                ? 'bg-pc-forest text-white shadow-xs'
                : 'text-pc-body hover:bg-pc-line'
            }`}
          >
            <Lightbulb className="w-3 h-3 text-[#EFC66B]" /> Hint
          </button>
          <button
            onClick={() => setAiMentorMode('Debug')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
              aiMentorMode === 'Debug'
                ? 'bg-pc-forest text-white shadow-xs'
                : 'text-pc-body hover:bg-pc-line'
            }`}
          >
            <Bug className="w-3 h-3" /> Debug
          </button>
          <button
            onClick={() => setAiMentorMode('Match')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
              aiMentorMode === 'Match'
                ? 'bg-pc-forest text-white shadow-xs'
                : 'text-pc-body hover:bg-pc-line'
            }`}
          >
            <UsersRound className="w-3 h-3 text-[#EFC66B]" /> Match
          </button>
        </div>
      </div>

      {/* Match preferences panel */}
      {aiMentorMode === 'Match' && (
        <form onSubmit={runMatch} className="px-3 py-2.5 border-b border-pc-line bg-pc-card space-y-2 text-[11px]">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-pc-muted" />
            <input
              value={kw}
              onChange={(e) => setKw(e.target.value)}
              placeholder="Skills & keywords, e.g. React, UI/UX, IoT, machine learning"
              className="w-full pl-8 pr-2 py-1.5 bg-pc-secondary/60 border border-pc-line focus:border-[#26783C] rounded-input text-pc-body placeholder-pc-muted outline-none"
            />
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            <select value={branch} onChange={(e) => setBranch(e.target.value)} className="px-1.5 py-1.5 bg-pc-secondary/60 border border-pc-line rounded-input text-pc-body outline-none truncate" title="Branch">
              {branchOptions.map((b) => <option key={b} value={b}>{b === 'Any' ? 'Any branch' : b}</option>)}
            </select>
            <select value={year} onChange={(e) => setYear(e.target.value)} className="px-1.5 py-1.5 bg-pc-secondary/60 border border-pc-line rounded-input text-pc-body outline-none" title="Year">
              {yearOptions.map((y) => <option key={y} value={y}>{y === 'Any' ? 'Any year' : y}</option>)}
            </select>
            <select value={level} onChange={(e) => setLevel(e.target.value as MatchQuery['minProficiency'])} className="px-1.5 py-1.5 bg-pc-secondary/60 border border-pc-line rounded-input text-pc-body outline-none" title="Minimum skill level">
              <option value="Any">Any level</option>
              <option value="Intermediate">Intermediate+</option>
              <option value="Advanced">Advanced+</option>
              <option value="Expert">Expert</option>
            </select>
          </div>
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-1.5 text-pc-muted cursor-pointer">
              <input type="checkbox" checked={verifiedOnly} onChange={(e) => setVerifiedOnly(e.target.checked)} className="rounded" />
              Verified skills only
            </label>
            <button type="submit" disabled={isAiThinking} className="px-3 py-1.5 bg-[#26783C] hover:bg-[#1C622F] disabled:opacity-50 text-white rounded-btn font-bold flex items-center gap-1.5">
              <UsersRound className="w-3.5 h-3.5" /> Find matches
            </button>
          </div>
        </form>
      )}

      {/* Attached Context Banner */}
      {selectedQuestionContext && (
        <div className="bg-pc-highlight/60 px-3 py-1.5 text-[11px] flex items-center justify-between border-b border-pc-line text-pc-ink">
          <div className="flex items-center gap-1.5 truncate">
            <FileCode className="w-3.5 h-3.5 text-pc-accent flex-shrink-0" />
            <span className="font-semibold truncate">Context:</span>
            <span className="truncate">{selectedQuestionContext.title} ({selectedQuestionContext.platform})</span>
          </div>
          <button
            onClick={() => setSelectedQuestionContext(null)}
            className="text-pc-muted hover:text-pc-error ml-2 flex-shrink-0"
            title="Detach context"
          >
            ✕
          </button>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5 text-xs bg-pc-card">
        {aiMessages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[88%] rounded-xl p-3 shadow-2xs relative group ${
                msg.role === 'user'
                  ? 'bg-pc-forest text-white rounded-br-xs'
                  : 'bg-pc-hover text-pc-body border border-pc-line rounded-bl-xs'
              }`}
            >
              {msg.role === 'assistant' && (
                <div className="flex items-center justify-between mb-1 pb-1 border-b border-pc-line/60 text-[10px] text-pc-muted">
                  <span className="font-bold text-pc-ink">AI Mentor ({msg.mode || 'Guidance'})</span>
                  <button
                    onClick={() => handleCopy(msg.id, msg.content)}
                    className="hover:text-pc-ink transition-colors"
                    title="Copy response"
                  >
                    {copiedId === msg.id ? (
                      <Check className="w-3 h-3 text-pc-accent" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>
                </div>
              )}

              {/* Render simple markdown/paragraphs */}
              <div className="space-y-1.5 leading-relaxed whitespace-pre-wrap font-sans">
                {msg.content}
              </div>

              {msg.matches && msg.matches.length > 0 && (
                <div className="mt-2.5 space-y-2">
                  {msg.matches.map((m) => {
                    const u = getUserById(m.userId);
                    if (!u) return null;
                    return (
                      <div key={m.userId} className="bg-pc-card border border-pc-line rounded-lg p-2.5 space-y-1.5">
                        <div className="flex items-center gap-2.5">
                          <img src={u.avatarUrl} alt={u.fullName} className="w-9 h-9 rounded-full object-cover bg-pc-secondary flex-shrink-0" />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-pc-ink truncate">{u.fullName}</span>
                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-pc-highlight text-pc-ink flex-shrink-0">{m.score}%</span>
                            </div>
                            <div className="text-[10px] text-pc-muted truncate">
                              {[u.branch, u.academicYear].filter(Boolean).join(' • ')}
                            </div>
                          </div>
                        </div>
                        {m.reasons.length > 0 && (
                          <ul className="text-[10.5px] text-pc-body space-y-0.5 list-disc pl-4">
                            {m.reasons.map((r, i) => <li key={i}>{r}</li>)}
                          </ul>
                        )}
                        <div className="flex justify-end">
                          <Link to={`/users/${u.id}`} onClick={() => setIsAiMentorOpen(false)} className="text-[11px] font-bold text-pc-accent hover:underline">
                            View profile →
                          </Link>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <div
                className={`text-[9px] mt-1 text-right ${
                  msg.role === 'user' ? 'text-[#A2BA95]' : 'text-pc-muted'
                }`}
              >
                {msg.createdAt}
              </div>
            </div>
          </div>
        ))}

        {isAiThinking && (
          <div className="flex items-center gap-2 text-pc-accent text-xs py-2 px-3 bg-pc-hover rounded-lg border border-pc-line w-fit">
            <Bot className="w-3.5 h-3.5 animate-bounce" />
            <span className="font-medium animate-pulse">{aiMentorMode === 'Match' ? 'Searching peer profiles…' : 'PeerCraft AI is analyzing algorithmic logic...'}</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="px-3 py-1.5 bg-pc-main border-t border-pc-line overflow-x-auto hide-scrollbar flex items-center gap-1.5 flex-nowrap">
        {(aiMentorMode === 'Match' ? matchPrompts : suggestedPrompts.slice(0, 4)).map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handlePromptClick(prompt)}
            className="text-[10px] px-2.5 py-1 rounded-full bg-pc-card hover:bg-pc-highlight text-pc-ink border border-pc-line whitespace-nowrap transition-colors flex-shrink-0"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input area */}
      <form
        onSubmit={handleSend}
        className="p-2.5 bg-pc-card border-t border-pc-line flex items-center gap-2"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={
            aiMentorMode === 'Learn'
              ? 'Ask for concept breakdown or approach...'
              : aiMentorMode === 'Match'
              ? 'Or just type: React developer, final year...'
              : aiMentorMode === 'Hint'
              ? 'Ask for progressive hints without spoilers...'
              : 'Paste code or edge case error...'
          }
          className="flex-1 px-3 py-2 text-xs bg-pc-secondary/60 focus:bg-pc-card border border-pc-line focus:border-[#26783C] rounded-input text-pc-body placeholder-pc-muted outline-none"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isAiThinking}
          className="p-2 bg-[#26783C] hover:bg-[#1C622F] disabled:opacity-40 text-white rounded-input transition-colors flex-shrink-0"
          title="Send message"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
